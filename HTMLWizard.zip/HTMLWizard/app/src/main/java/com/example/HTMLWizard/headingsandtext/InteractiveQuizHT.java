package com.example.HTMLWizard.headingsandtext;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.HTMLWizard.R;


public class InteractiveQuizHT extends AppCompatActivity {
    private TextView questionTextView;
    private RadioGroup radioGroup;
    private Button submitButton;
    private int questionIndex = 0;
    private ImageButton backArrowButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_interactive_quiz_ht);

        questionTextView = findViewById(R.id.questionTextView);
        radioGroup = findViewById(R.id.radioGroup);
        submitButton = findViewById(R.id.submitButton);

        displayQuestion(questionIndex);

        submitButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                checkAnswer();
            }
        });


        backArrowButton = findViewById(R.id.backArrow);
        backArrowButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

    }

    private void displayQuestion(int questionIndex) {
        questionTextView.setText(QuestionAnswerHT.question[questionIndex]);

        radioGroup.removeAllViews();
        for (int i = 0; i < QuestionAnswerHT.choices[questionIndex].length; i++) {
            RadioButton radioButton = new RadioButton(this);
            radioButton.setText(QuestionAnswerHT.choices[questionIndex][i]);
            radioGroup.addView(radioButton);
        }
    }

    private void checkAnswer() {
        int selectedRadioButtonId = radioGroup.getCheckedRadioButtonId();

        if (selectedRadioButtonId != -1) {
            RadioButton selectedRadioButton = findViewById(selectedRadioButtonId);
            String selectedAnswer = selectedRadioButton.getText().toString();

            if (selectedAnswer.equals(QuestionAnswerHT.correctAnswers[questionIndex])) {
                Intent intent = new Intent(this, ConclusionHT.class);
                startActivity(intent);
            } else {
                Toast.makeText(this, "Incorrect Answer", Toast.LENGTH_SHORT).show();
            }
        } else {
            Toast.makeText(this, "Please select an answer", Toast.LENGTH_SHORT).show();
        }
    }
}
