package com.example.HTMLWizard.hyperlinksandanchors;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.example.HTMLWizard.R;

public class HyperlinksIntro extends AppCompatActivity {

    ImageButton html_intro_1;
    RelativeLayout relativeLayout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.base_activity_layout);

        html_intro_1 = findViewById(R.id.html_intro_1);

        html_intro_1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(com.example.HTMLWizard.hyperlinksandanchors.HyperlinksIntro.this, LinkTypes.class);
                startActivity(intent);
            }
        });

        relativeLayout = findViewById(R.id.lesson_text);


        TextView textView = new TextView(this);
        textView.setLayoutParams(new RelativeLayout.LayoutParams(
                RelativeLayout.LayoutParams.WRAP_CONTENT,
                RelativeLayout.LayoutParams.WRAP_CONTENT));

        textView.setText("Hyperlinks are pieces of text which are commonly highlighted and underlined in a blue colour to visually show the user that it can be clicked and an action will happen. They are commonly used for taking a user to another website or another part of the same website. Behind the hyperlinks we have URLs (Uniform Resource Locator) which tells the browser the location of where the hyperlink is going to send the user.\n\n"
                +
                "They have a crucial role in connecting multiple web pages across the internet and allow users to go to another web page without manually typing it in. They hugely enhance the user experience because it means as a user there is less work to do to find what you are looking for on the internet. Without hyperlinks the internet would be very disconnected which makes it challenging for users to discover what they are searching for and may find it difficult to navigate through web pages.\n\n"
                +
                "Hyperlinks can improve overall user retention for your web page as well, hyperlinks from other web pages or search engines can direct a user to your page and therefore spend more time on your website. Providing clear information about the content of your website can make it easier for search engines to recommend your site.\n");

        relativeLayout.addView(textView);
    }
}