package com.example.HTMLWizard.tablesandttags;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.example.HTMLWizard.R;

public class TableStructure extends AppCompatActivity {

    ImageButton html_intro_1;
    RelativeLayout relativeLayout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.base_activity_layout);

        html_intro_1 = findViewById(R.id.html_intro_1);

        html_intro_1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(com.example.HTMLWizard.tablesandttags.TableStructure.this, Attributes.class);
                startActivity(intent);
            }
        });


        relativeLayout = findViewById(R.id.lesson_text);


        TextView textView = new TextView(this);
        textView.setLayoutParams(new RelativeLayout.LayoutParams(
                RelativeLayout.LayoutParams.WRAP_CONTENT,
                RelativeLayout.LayoutParams.WRAP_CONTENT));

        textView.setText("< table >: This tag starts off the table code and defines it in our code. It is the parent container for the rest of the tags which need to be included to build a functional table. Embedded in this tag we need to include headers, rows and data cells.\n\n"
                +
                "< tr >: This tag defines the table row. Each of these tags represent a horizontal row for our data. It is commonly used as a direct child to the < table > parent tag, but it can also be nested in a < thead > or < tfoot > tag.\n\n"
                +
                "< th >: This tag defines the table's header. They are normally in bold writing and centred, they just constrain headers rather than data which contributes to the table. They are used commonly to label rows and columns within the table. Using < th > tags in a table explicitly tells the browser that it is representing a header and not a regular piece of data, this is what we mean by context. In the use of assistive technologies such as screen readers the importance of context is huge because it is used to specify what is regular data in the table and what is the header for the table.\n\n"
                +
                "< td >: This tag defines the data cell which is where we include data in our table. This is where the bulk of the content will be and where we will see text, images or any other content you want to include in the table.");

        relativeLayout.addView(textView);
    }
}