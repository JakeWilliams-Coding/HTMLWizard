package com.example.HTMLWizard.htmlforms;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.example.HTMLWizard.MainActivity;
import com.example.HTMLWizard.R;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class ConclusionHF extends AppCompatActivity {

    ImageButton html_intro_1;
    RelativeLayout relativeLayout;
    DatabaseReference databaseReference;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.base_activity_layout);



        databaseReference = FirebaseDatabase.getInstance().getReference("buttons");

        html_intro_1 = findViewById(R.id.html_intro_1);


        html_intro_1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                databaseReference.child("big_quiz_start").setValue(true);
                Intent intent = new Intent(ConclusionHF.this, MainActivity.class);
                startActivity(intent);
            }
        });

        relativeLayout = findViewById(R.id.lesson_text);


        TextView textView = new TextView(this);
        textView.setLayoutParams(new RelativeLayout.LayoutParams(
                RelativeLayout.LayoutParams.WRAP_CONTENT,
                RelativeLayout.LayoutParams.WRAP_CONTENT));

        textView.setText("To conclude this lesson we have learnt that HTML forms server multiple purposes and which include user retention, user engagement and the overall web page functionality.\n\n"
                +
                "Proper structure when using HTML forms is important when including elements such as attributes such as the different input types there are available or the action attribute. They all need to be implemented properly for the intended outcome of your HTML form.\n\n"
                +
                "Input elements are a crucial part of forms as they are what allow the user to input their data so we can use it as it is intended. Elements such as < button > < input > are the base for our forms which gather user input data and then use this to trigger other actions within our web page. We also have common attributes such as name, type and placeholder which help support the identification process to then process the data.\n\n"
                +
                "An important step to keep in mind is remembering to close your form tags, this is essential for maintaining the intended functionality of the web page as a whole and maintaining good code structure as well. Closing your tags will prevent issues such as rendering problems or potentially accessibility issues because elements will not be displayed properly.");

        relativeLayout.addView(textView);
    }
}