package com.example.HTMLWizard.ImagesAndAudio;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.example.HTMLWizard.R;;

public class AudioElements extends AppCompatActivity {

    ImageButton html_intro_1;
    RelativeLayout relativeLayout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.base_activity_layout);

        html_intro_1 = findViewById(R.id.html_intro_1);

        html_intro_1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(com.example.HTMLWizard.ImagesAndAudio.AudioElements.this, AudioAttributesExercise.class);
                startActivity(intent);
            }
        });


        relativeLayout = findViewById(R.id.lesson_text);


        TextView textView = new TextView(this);
        textView.setLayoutParams(new RelativeLayout.LayoutParams(
                RelativeLayout.LayoutParams.WRAP_CONTENT,
                RelativeLayout.LayoutParams.WRAP_CONTENT));

        textView.setTextColor(ContextCompat.getColor(this, R.color.textColor));

        textView.setText("The <audio> tag is used to embed audio content into web pages. Here is an example of what the code looks like: <audio src=\"audio.mp3\"></audio>. Similar to the <img> tag it also has several attributes which can also be applied to it to change how it performs. Below are some attributes which you can apply to your audio element.\n\n"
                +
                "Controls: The control attribute will make the browser display a set of playback controls for the audio player such as pause, play, volume control etc. This means the user can interact with the audio element and adjust settings as they see fit.\n\n"
                +
                "Autoplay: The autoplay attribute does exactly what you think it would do, when the user's browser loads the page the audio will automatically start playing. However, it is important to keep in mind that not all users may want to hear the audio and may create a disruptive user experience.\n\n"
                +
                "Loop: The loop attribute makes the present audio loop once it has reached the end. This is used commonly for quiet background music which won’t necessarily disrupt the user's experience.");

        relativeLayout.addView(textView);
    }
}