package com.example.HTMLWizard;


import static android.content.ContentValues.TAG;

import android.Manifest;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.provider.Settings;
import android.text.TextUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatDelegate;
import androidx.appcompat.widget.SwitchCompat;
import androidx.core.app.ActivityCompat;
import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;
import androidx.fragment.app.Fragment;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.material.bottomsheet.BottomSheetDialog;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.HashMap;
import java.util.Map;

public class MyprofileFragment extends Fragment {

    private SwitchCompat switchCompat;
    private SharedPreferences sharedPreferences;
    private static final int PERMISSION_REQUEST_CODE = 100;
    private static final int NOTIFICATION_ID = 1;
    private static final String CHANNEL_ID = "MyNotificationChannel";
    private Handler handler = new Handler();
    private Runnable notificationRunnable;
    private TextView textView;
    private DatabaseReference mDatabaseRef;
    private TextView usernametextView;


    private ImageView simpleHtmlImageView;
    private ImageView headingsAndTextView;
    private ImageView imagesandAudioView;
    private ImageView listTypesView;
    private ImageView tablesAndTagsView;
    private ImageView hyperlinksAndAnchorsView;
    private ImageView htmlFormsView;
    private ImageView bigQuizView;



    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.fragment_myprofile, container, false);

        switchCompat = rootView.findViewById(R.id.darkmodeswitch);

        sharedPreferences = requireActivity().getSharedPreferences("my_preferences", Context.MODE_PRIVATE);
        sharedPreferences = requireActivity().getSharedPreferences("night", 0);

        boolean isNightModeEnabled = sharedPreferences.getBoolean("night_mode", false);
        switchCompat.setChecked(isNightModeEnabled);

        textView = rootView.findViewById(R.id.usernametextView);


        switchCompat.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                SharedPreferences.Editor editor = sharedPreferences.edit();
                editor.putBoolean("night_mode", isChecked);
                editor.apply();
                AppCompatDelegate.setDefaultNightMode(isChecked ?
                        AppCompatDelegate.MODE_NIGHT_YES : AppCompatDelegate.MODE_NIGHT_NO);
            }
        });

        Button changePasswordButton = rootView.findViewById(R.id.changePassword);
        changePasswordButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showChangePasswordDialog();
            }
        });


        Button signoutButton = rootView.findViewById(R.id.signOut);
        signoutButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getActivity(), LoginActivity.class);
                startActivity(intent);
            }
        });


        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            if (ActivityCompat.checkSelfPermission(requireContext(), Manifest.permission.SYSTEM_ALERT_WINDOW) != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(requireActivity(), new String[]{Manifest.permission.SYSTEM_ALERT_WINDOW}, PERMISSION_REQUEST_CODE);
            }
        }

        Button notificationsButton = rootView.findViewById(R.id.notificationsbutton);
        notificationsButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openAppNotificationsSettings();
            }
        });



        TextView textView = rootView.findViewById(R.id.usernametextView);
        textView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showOverlay();
            }
        });

        usernametextView = rootView.findViewById(R.id.usernametextView);

        String savedText = sharedPreferences.getString("usernametextView_text", "");
        if (!savedText.isEmpty()) {
            usernametextView.setText(savedText);
        } else {
            usernametextView.setText("Default Username");
        }



        simpleHtmlImageView = rootView.findViewById(R.id.Simplehtmlbadge);

        mDatabaseRef = FirebaseDatabase.getInstance().getReference().child("users")
                .child(FirebaseAuth.getInstance().getCurrentUser().getUid()).child("buttons").child("headings_and_text_start");
        mDatabaseRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                boolean value = dataSnapshot.getValue(Boolean.class);
                if (value) {
                    simpleHtmlImageView.setImageResource(R.drawable.editor_choice_complete_24px);
                } else {
                    simpleHtmlImageView.setImageResource(R.drawable.editor_choice_24px);
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
            }
        });

        headingsAndTextView = rootView.findViewById(R.id.Addinghandtbadge);

        mDatabaseRef = FirebaseDatabase.getInstance().getReference().child("users")
                .child(FirebaseAuth.getInstance().getCurrentUser().getUid()).child("buttons").child("images_and_audio_start");
        mDatabaseRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                boolean value = dataSnapshot.getValue(Boolean.class);
                if (value) {
                    headingsAndTextView.setImageResource(R.drawable.editor_choice_complete_24px);
                } else {
                    headingsAndTextView.setImageResource(R.drawable.editor_choice_24px);
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
            }
        });


        imagesandAudioView = rootView.findViewById(R.id.Addingiandabadge);

        mDatabaseRef = FirebaseDatabase.getInstance().getReference().child("users")
                .child(FirebaseAuth.getInstance().getCurrentUser().getUid()).child("buttons").child("list_types_start");
        mDatabaseRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                boolean value = dataSnapshot.getValue(Boolean.class);
                if (value) {
                    imagesandAudioView.setImageResource(R.drawable.editor_choice_complete_24px);
                } else {
                    imagesandAudioView.setImageResource(R.drawable.editor_choice_24px);
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
            }
        });


        listTypesView = rootView.findViewById(R.id.Listtypesanddivsbadge);

        mDatabaseRef = FirebaseDatabase.getInstance().getReference().child("users")
                .child(FirebaseAuth.getInstance().getCurrentUser().getUid()).child("buttons").child("tables_and_ttags_start");
        mDatabaseRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                boolean value = dataSnapshot.getValue(Boolean.class);
                if (value) {
                    listTypesView.setImageResource(R.drawable.editor_choice_complete_24px);
                } else {
                    listTypesView.setImageResource(R.drawable.editor_choice_24px);
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
            }
        });


        tablesAndTagsView = rootView.findViewById(R.id.Tablesandttagsbadge);

        mDatabaseRef = FirebaseDatabase.getInstance().getReference().child("users")
                .child(FirebaseAuth.getInstance().getCurrentUser().getUid()).child("buttons").child("hyperlinks_and_anchors_start");
        mDatabaseRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                boolean value = dataSnapshot.getValue(Boolean.class);
                if (value) {
                    tablesAndTagsView.setImageResource(R.drawable.editor_choice_complete_24px);
                } else {
                    tablesAndTagsView.setImageResource(R.drawable.editor_choice_24px);
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
            }
        });



        hyperlinksAndAnchorsView = rootView.findViewById(R.id.hyperlinksandanchorsbadge);

        mDatabaseRef = FirebaseDatabase.getInstance().getReference().child("users")
                .child(FirebaseAuth.getInstance().getCurrentUser().getUid()).child("buttons").child("html_forms_start");
        mDatabaseRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                boolean value = dataSnapshot.getValue(Boolean.class);
                if (value) {
                    hyperlinksAndAnchorsView.setImageResource(R.drawable.editor_choice_complete_24px);
                } else {
                    hyperlinksAndAnchorsView.setImageResource(R.drawable.editor_choice_24px);
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });


        htmlFormsView = rootView.findViewById(R.id.htmlformsbadge);

        mDatabaseRef = FirebaseDatabase.getInstance().getReference().child("users")
                .child(FirebaseAuth.getInstance().getCurrentUser().getUid()).child("buttons").child("big_quiz_start");
        mDatabaseRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                boolean value = dataSnapshot.getValue(Boolean.class);
                if (value) {
                    htmlFormsView.setImageResource(R.drawable.editor_choice_complete_24px);
                } else {
                    htmlFormsView.setImageResource(R.drawable.editor_choice_24px);
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
            }
        });


        bigQuizView = rootView.findViewById(R.id.thebigquizbadge);

        mDatabaseRef = FirebaseDatabase.getInstance().getReference().child("users")
                .child(FirebaseAuth.getInstance().getCurrentUser().getUid()).child("buttons").child("big_quiz_start");
        mDatabaseRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                boolean value = dataSnapshot.getValue(Boolean.class);
                if (value) {
                    bigQuizView.setImageResource(R.drawable.editor_choice_complete_24px);
                } else {
                    bigQuizView.setImageResource(R.drawable.editor_choice_24px);
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
            }
        });

        return rootView;
    }


    private void showOverlay() {
        View overlayView = getLayoutInflater().inflate(R.layout.overlay_layout, null);

        EditText inputEditText = overlayView.findViewById(R.id.editText);
        Button submitButton = overlayView.findViewById(R.id.submitBtn);

        AlertDialog.Builder builder = new AlertDialog.Builder(requireContext());
        builder.setView(overlayView);
        AlertDialog dialog = builder.create();
        dialog.show();


        submitButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String userInput = inputEditText.getText().toString().trim();
                if (!userInput.isEmpty()) {
                    addToFirestore(userInput);
                    usernametextView.setText(userInput);

                    SharedPreferences.Editor editor = sharedPreferences.edit();
                    editor.putString("usernametextView_text", userInput);
                    editor.apply();

                    dialog.dismiss();
                } else {
                    Toast.makeText(requireContext(), "Please enter something", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }



    private void addToFirestore(String userInput) {
        FirebaseFirestore db = FirebaseFirestore.getInstance();

        Map<String, Object> userInputData = new HashMap<>();
        userInputData.put("input", userInput);

        db.collection("userInputs")
                .add(userInputData)
                .addOnSuccessListener(new OnSuccessListener<DocumentReference>() {
                    @Override
                    public void onSuccess(DocumentReference documentReference) {
                        Log.d(TAG, "DocumentSnapshot added with ID: " + documentReference.getId());
                    }
                })
                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        Log.w(TAG, "Error adding document", e);
                    }
                });
    }


    private void openAppNotificationsSettings() {
        Intent intent = new Intent();
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            intent.setAction(Settings.ACTION_APP_NOTIFICATION_SETTINGS);
            intent.putExtra(Settings.EXTRA_APP_PACKAGE, requireActivity().getPackageName());
        } else {
            intent.setAction(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
            Uri uri = Uri.fromParts("package", requireActivity().getPackageName(), null);
            intent.setData(uri);
        }
        startActivity(intent);
    }

    private void showChangePasswordDialog() {

        View dialogView = getLayoutInflater().inflate(R.layout.dialog_change_password, null);

        EditText emailEditText = dialogView.findViewById(R.id.emailEditText);
        Button submitEmailButton = dialogView.findViewById(R.id.submitEmailButton);

        BottomSheetDialog dialog = new BottomSheetDialog(requireContext());
        dialog.setContentView(dialogView);
        dialog.show();

        submitEmailButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String email = emailEditText.getText().toString().trim();
                resetPassword(email);
                dialog.dismiss();
            }
        });
    }

    private void resetPassword(String email) {
        FirebaseAuth.getInstance().sendPasswordResetEmail(email)
                .addOnCompleteListener(task -> {
                    if (task.isSuccessful()) {
                        Toast.makeText(requireContext(), "Password reset email sent", Toast.LENGTH_SHORT).show();
                    } else {
                        Toast.makeText(requireContext(), "Failed to send reset email", Toast.LENGTH_SHORT).show();
                    }
                });
    }

    @Override
    public void onPause() {
        super.onPause();

        handler.removeCallbacks(notificationRunnable);
        notificationRunnable = new Runnable() {
            @Override
            public void run() {
                sendNotification();
            }
        };
        handler.postDelayed(notificationRunnable, 150000);
    }

    @Override
    public void onResume() {
        super.onResume();

        String savedText = sharedPreferences.getString("user_input_text", "");

        if (!TextUtils.isEmpty(savedText)) {
            textView.setText(savedText);
        }
        handler.removeCallbacks(notificationRunnable);
    }


    private void sendNotification() {
        if (areNotificationsEnabled()) {
            createNotificationChannel();

            NotificationCompat.Builder builder = new NotificationCompat.Builder(requireContext(), CHANNEL_ID)
                    .setSmallIcon(R.drawable.ic_launcher_foreground)
                    .setContentTitle("Notification Title")
                    .setContentText("Notification content")
                    .setPriority(NotificationCompat.PRIORITY_DEFAULT);

            NotificationManager notificationManager = (NotificationManager) requireContext().getSystemService(Context.NOTIFICATION_SERVICE);
            notificationManager.notify(NOTIFICATION_ID, builder.build());
        } else {
            showEnableNotificationsDialog();
        }
    }

    private void showEnableNotificationsDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(requireContext());
        builder.setTitle("Enable Notifications");
        builder.setMessage("Please enable notifications for this app to receive alerts.");
        builder.setPositiveButton("Settings", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                // Open app settings
                Intent intent = new Intent();
                intent.setAction(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
                intent.setData(Uri.fromParts("package", requireContext().getPackageName(), null));
                startActivity(intent);
            }
        });
        builder.setNegativeButton("Cancel", null);
        AlertDialog dialog = builder.create();
        dialog.getWindow().setType(WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY);
        dialog.show();
    }

    private boolean areNotificationsEnabled() {
        NotificationManagerCompat notificationManagerCompat = NotificationManagerCompat.from(requireContext());
        return notificationManagerCompat.areNotificationsEnabled();
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            CharSequence name = "My Notification Channel";
            String description = "Notification Channel Description";
            int importance = NotificationManager.IMPORTANCE_DEFAULT;
            NotificationChannel channel = new NotificationChannel(CHANNEL_ID, name, importance);
            channel.setDescription(description);

            NotificationManager notificationManager = requireContext().getSystemService(NotificationManager.class);
            notificationManager.createNotificationChannel(channel);
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == PERMISSION_REQUEST_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            } else {
            }
        }
    }
}









