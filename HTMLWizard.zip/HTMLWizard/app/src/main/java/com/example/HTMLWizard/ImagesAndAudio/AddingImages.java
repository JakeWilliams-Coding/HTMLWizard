package com.example.HTMLWizard.ImagesAndAudio;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.example.HTMLWizard.R;

public class AddingImages extends AppCompatActivity {

    ImageButton html_intro_1;
    RelativeLayout relativeLayout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.base_activity_layout);

        html_intro_1 = findViewById(R.id.html_intro_1);

        html_intro_1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(com.example.HTMLWizard.ImagesAndAudio.AddingImages.this, ImageAttributeExercise.class);
                startActivity(intent);
            }
        });

        relativeLayout = findViewById(R.id.lesson_text);


        TextView textView = new TextView(this);
        textView.setLayoutParams(new RelativeLayout.LayoutParams(
                RelativeLayout.LayoutParams.WRAP_CONTENT,
                RelativeLayout.LayoutParams.WRAP_CONTENT));

        textView.setTextColor(ContextCompat.getColor(this, R.color.textColor));

        textView.setText("The <img> tag is used to insert images into your web page. It has a self-closing tag which means you do not need to include a closing tag. It can include multiple attributes inside it which can change how the image will be displayed. Below are some attributes used for this purpose:\n\n"
                +
                "Src (Source): This attribute is mandatory for the image to display on the web page as it specifies the URL where the image is taken from. The SRC will tell the user's browser where they can fetch the image to display on the screen.\n\n"
                +
                "Alt (Alternative Text): The alt attribute provides alternative text for the image if it cannot be loaded or if the user is using a screen reader. It acts as a placeholder when an image is not being displayed. It also has a role in helping search engines understand the content of the image and aid the user in images that may be similar to it.\n\n"
                +
                "We talked about CSS in the previous lesson, but this is directed towards CSS Images. It can be used to create responsive images and scale properly on the web page. A common technique many developers use for responsive images is ‘max-width: 100%’ which scales the image’s width to fill the parent element. So no matter what device they are using, the image will still take up the same layout space on the page. An additional benefit of this attribute is it prevents the image from overflowing or becoming blurry on smaller screen sizes.");

        relativeLayout.addView(textView);
    }
}