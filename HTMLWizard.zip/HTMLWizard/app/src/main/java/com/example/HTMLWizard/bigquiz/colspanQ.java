package com.example.HTMLWizard.bigquiz;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import com.example.HTMLWizard.R;


public class colspanQ extends AppCompatActivity {
    private TextView questionTextView;
    private RadioGroup radioGroup;
    private Button submitButton;
    private ImageButton backArrowButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_colspan_q);

        questionTextView = findViewById(R.id.questionTextView);
        radioGroup = findViewById(R.id.radioGroup);
        submitButton = findViewById(R.id.submitButton);

        displayQuestion(6);

        submitButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                checkAnswer();
            }
        });

        backArrowButton = findViewById(R.id.backArrow);
        backArrowButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }


    private void displayQuestion(int questionIndex) {
        questionTextView.setText(QuestionAnswerBQ.question[questionIndex]);

        radioGroup.removeAllViews();
        for (int i = 0; i < QuestionAnswerBQ.choices[questionIndex].length; i++) {
            RadioButton radioButton = new RadioButton(this);
            radioButton.setText(QuestionAnswerBQ.choices[questionIndex][i]);
            radioGroup.addView(radioButton);
        }
    }

    private void checkAnswer() {
        int selectedRadioButtonId = radioGroup.getCheckedRadioButtonId();

        if (selectedRadioButtonId != -1) {
            RadioButton selectedRadioButton = findViewById(selectedRadioButtonId);
            String selectedAnswer = selectedRadioButton.getText().toString();

            if (selectedAnswer.equals(QuestionAnswerBQ.correctAnswers[1])) {
                Intent intent = new Intent(this, mainHeadingQ.class);
                startActivity(intent);
            } else {
                Toast.makeText(this, "Incorrect Answer", Toast.LENGTH_SHORT).show();
            }
        } else {
            Toast.makeText(this, "Please select an answer", Toast.LENGTH_SHORT).show();
        }
    }


}