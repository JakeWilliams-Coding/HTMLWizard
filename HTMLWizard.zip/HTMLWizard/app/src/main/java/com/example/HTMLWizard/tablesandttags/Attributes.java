package com.example.HTMLWizard.tablesandttags;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.example.HTMLWizard.R;

public class Attributes extends AppCompatActivity {

    ImageButton html_intro_1;
    RelativeLayout relativeLayout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.base_activity_layout);

        html_intro_1 = findViewById(R.id.html_intro_1);
        html_intro_1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(com.example.HTMLWizard.tablesandttags.Attributes.this, StylingTables.class);
                startActivity(intent);
            }
        });

        relativeLayout = findViewById(R.id.lesson_text);

        TextView textView = new TextView(this);
        textView.setLayoutParams(new RelativeLayout.LayoutParams(
                RelativeLayout.LayoutParams.WRAP_CONTENT,
                RelativeLayout.LayoutParams.WRAP_CONTENT));

        textView.setText("Border: This attribute specifies the width of the table border and if you want the border to be visible or not. We assign a value to this attribute to specific the amount of pixels wide we want the border to be. For example we can set it to this - border=&quot; 3 &quot;, which means the width around the table will be 3 pixels.\n\n"
                +
                "Cellpadding: This attribute specifies the empty space between the inside of the cell where all the content is and the edge of the border. For example if you choose a higher value, the text content inside will be centred with a large gap all around it until you reach the border. We can do this similarly to the border attribute, for example: cellpadding= &quot; 8 &quot;\n\n"
                +
                "Cellspacing: This attribute specifies the space between each cell which has the data content in. Like the previous attributes we assign an integer value representing the amount of pixels that we want to assign. For example: cellspacing= &quot; 3 &quot; sets the spacing between the different cells to 3 pixels.\n");

        relativeLayout.addView(textView);
    }
}