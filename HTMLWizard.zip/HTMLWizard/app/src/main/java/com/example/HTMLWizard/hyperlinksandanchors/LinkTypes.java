package com.example.HTMLWizard.hyperlinksandanchors;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.example.HTMLWizard.R;

public class LinkTypes extends AppCompatActivity {

    ImageButton html_intro_1;
    RelativeLayout relativeLayout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.base_activity_layout);

        html_intro_1 = findViewById(R.id.html_intro_1);

        html_intro_1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(com.example.HTMLWizard.hyperlinksandanchors.LinkTypes.this, StylingLinks.class);
                startActivity(intent);
            }
        });


        relativeLayout = findViewById(R.id.lesson_text);


        TextView textView = new TextView(this);
        textView.setLayoutParams(new RelativeLayout.LayoutParams(
                RelativeLayout.LayoutParams.WRAP_CONTENT,
                RelativeLayout.LayoutParams.WRAP_CONTENT));

        textView.setText("Absolute URLs:\n\n" +
                "\n" +
                "There are 2 different URL types, the first being absolute URLs which provide a full web address to another website and commonly starts with HTTPS or HTTP and then the name of the website otherwise known as the domain name. It specifies the direct location of the website you link to, so the spelling of the domain name and path to any resources you may be trying to link need to be completely identical for a hyperlink to work. An example of an absolute URL is: https://www.google.com/.\n\n"
                +
                "Then we have Relative URLs which are the hyperlinks that take the user to a different part of the current web page they are on. This is like the ‘Go to top’ link I described previously. This link only needs a path to the resource you want to take the user to. For example: ‘images/picture.png’.\n\n"
                +
                "The < a > tag means anchor and is a fundamental attribute when coding hyperlinks into your web page. It creates a link between the current web page and another destination you want the user to go to. Below is example code of how the < a > tag can be used:\n\n" +
                "\n" +
                "< a href= &quot; destination_url &quot; > Link Text < /a >\n\n"
                +
                "As seen in the example above after the ‘a’ we can see the ‘href’ attribute. This is a crucial part of the <tag> as it is responsible for defining the destination of the hyperlink embedded. This is what specifies the URL of the web page you are trying to send the user to. With the hyperlinks, we can also use them to take a user to elsewhere on the same web page. For example you may see on some web pages at the bottom of the site it will say ‘To the top’ or something similar. With this method you can take the user to a specific part of the web page you are already on. You just need to give an ID to the specified part of the web page so it knows what part of the web page to show to the user.\n\n"
                +
                "< a href= &quot; #section2 &quot; >here < /a >\n");

        relativeLayout.addView(textView);
    }
}