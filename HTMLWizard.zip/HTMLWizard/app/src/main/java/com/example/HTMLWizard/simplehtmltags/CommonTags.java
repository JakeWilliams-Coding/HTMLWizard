package com.example.HTMLWizard.simplehtmltags;


import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.example.HTMLWizard.R;

public class CommonTags extends AppCompatActivity {

    ImageButton html_intro_1;
    RelativeLayout relativeLayout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.base_activity_layout);

        html_intro_1 = findViewById(R.id.html_intro_1);

        html_intro_1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(CommonTags.this, TagIdentification.class);
                startActivity(intent);
            }
        });

        relativeLayout = findViewById(R.id.lesson_text);


        TextView textView = new TextView(this);
        textView.setLayoutParams(new RelativeLayout.LayoutParams(
                RelativeLayout.LayoutParams.WRAP_CONTENT,
                RelativeLayout.LayoutParams.WRAP_CONTENT));

        textView.setTextColor(ContextCompat.getColor(this, R.color.textColor));

        textView.setText("Below are some common HTML tags which you will use throughout any web-page development.\n\n"
                + "<h1> to <h6> - This tag is to create a heading for your web-page. h1 is the largest heading and is at the top of the heading hierarchy, and h6 is the smallest of the headings and is at the bottom of the hierarchy.\n\n"

                + "<p> - This tag is used to define the paragraph element. Any text enclosed within this tag will be shown in a paragraph format. This element lower on the hierarchy compared with headings so it would visually be underneath the headings like paragraphs in an essay.\n\n"

                + "<img> - This tag embeds images onto the web-page, this is split up into two parts when implementing it. The src attribute and the alt attribute which will be explained in more details in an upcoming lesson.\n\n"
                +
                "<div> - This tag is to define divisions and sections with your web-page. This is used primarily for layout purposes as it can group together any elements which you embed inside this tag. We normally wrap <p> text inside the <div> tags in terms of hierarchy.");

        relativeLayout.addView(textView);

        ImageButton backArrowButton = findViewById(R.id.backArrow);
        backArrowButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }
}