package com.example.HTMLWizard.ImagesAndAudio;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.example.HTMLWizard.MainActivity;
import com.example.HTMLWizard.R;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class ConclusionIA extends AppCompatActivity {

    ImageButton html_intro_1;
    RelativeLayout relativeLayout;
    DatabaseReference databaseReference;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.base_activity_layout);


        FirebaseDatabase database = FirebaseDatabase.getInstance();
        String userId = FirebaseAuth.getInstance().getCurrentUser().getUid();
        databaseReference = database.getReference("users").child(userId).child("buttons");

        html_intro_1 = findViewById(R.id.html_intro_1);

        html_intro_1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                databaseReference.child("list_types_start").setValue(true);
                Intent intent = new Intent(ConclusionIA.this, MainActivity.class);
                startActivity(intent);
            }
        });

        relativeLayout = findViewById(R.id.lesson_text);


        TextView textView = new TextView(this);
        textView.setLayoutParams(new RelativeLayout.LayoutParams(
                RelativeLayout.LayoutParams.WRAP_CONTENT,
                RelativeLayout.LayoutParams.WRAP_CONTENT));

        textView.setTextColor(ContextCompat.getColor(this, R.color.textColor));

        textView.setText("The <img> tag allows developers to embed images into their web pages, using attributes such as src, alt, width and height which allows you to change how it is viewed on your web page. Again, accessibility is key. So you must be including the alt attribute to help users who may be using screen readers.\n\n"
                +
                "Similarly the <audio> tag can provide the user with some background noise or more importantly audio for a video they may be watching on the web page. There are attributes that can be used to change the characteristics such as src, controls, autoplay and loop. Also, having a fallback option for audio can ensure broader compatibility over browsers and systems.\n\n"
                +
                "Finally, we talk about the different audio formats and why MP3 is more preferable over WAV format for most situations. The WAV file will be used more commonly in professional videos where the audio needs to have a superior quality. But for most general use, MP3 files are the default choice for developers.");

        relativeLayout.addView(textView);
    }
}