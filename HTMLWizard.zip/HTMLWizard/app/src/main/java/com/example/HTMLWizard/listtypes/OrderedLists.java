package com.example.HTMLWizard.listtypes;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.example.HTMLWizard.R;

public class OrderedLists extends AppCompatActivity {

    ImageButton html_intro_1;
    RelativeLayout relativeLayout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.base_activity_layout);

        html_intro_1 = findViewById(R.id.html_intro_1);

        html_intro_1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(com.example.HTMLWizard.listtypes.OrderedLists.this, UnorderedLists.class);
                startActivity(intent);
            }
        });


        relativeLayout = findViewById(R.id.lesson_text);


        TextView textView = new TextView(this);
        textView.setLayoutParams(new RelativeLayout.LayoutParams(
                RelativeLayout.LayoutParams.WRAP_CONTENT,
                RelativeLayout.LayoutParams.WRAP_CONTENT));

        textView.setText("Ordered Lists: Ordered lists are implemented using the < ol >. This will automatically create a list of items you will implement in an ordered manner.  Each item you include in this list be numbered, by default this will start from 1. But you can specify otherwise if you would like to start the list at a different number.\n\n"
                +
                "However we need more than just the < ol > tag, to add text into it we need to embed the list tag (< li >). Any text we want to include on our ordered list must be tag list tags for it to show on the web page. Below are some examples of how you can structure an ordered list:\n\n" +
                "\n" +
                "< ol >\n" +
                "  < li >This< /li >\n" +
                "  < li >Is < /li >\n" +
                "  < li >HTML < /li >\n" +
                "< /ol >\n"
                +
                "Then as stated we can start the number order from a different number if you choose to do so. This is how it would be done:\n\n" +
                "\n" +
                "< ol start=\"10\" >\n" +
                "  < li >Coffee < /li >\n" +
                "  < li > Tea < /li >\n" +
                "  < li > Milk < /li >\n" +
                "< /ol >\n");

        relativeLayout.addView(textView);
    }
}