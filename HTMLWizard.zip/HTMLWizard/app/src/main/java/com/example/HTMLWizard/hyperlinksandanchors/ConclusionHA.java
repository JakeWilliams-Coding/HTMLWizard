package com.example.HTMLWizard.hyperlinksandanchors;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.example.HTMLWizard.MainActivity;
import com.example.HTMLWizard.R;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class ConclusionHA extends AppCompatActivity {

    ImageButton html_intro_1;
    RelativeLayout relativeLayout;
    DatabaseReference databaseReference;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.base_activity_layout);


        databaseReference = FirebaseDatabase.getInstance().getReference("buttons");

        html_intro_1 = findViewById(R.id.html_intro_1);

        html_intro_1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                databaseReference.child("html_forms_start").setValue(true);
                Intent intent = new Intent(ConclusionHA.this, MainActivity.class);
                startActivity(intent);
            }
        });

        relativeLayout = findViewById(R.id.lesson_text);


        TextView textView = new TextView(this);
        textView.setLayoutParams(new RelativeLayout.LayoutParams(
                RelativeLayout.LayoutParams.WRAP_CONTENT,
                RelativeLayout.LayoutParams.WRAP_CONTENT));

        textView.setText("To conclude this lesson hyperlinks play a crucial role in connecting web pages across the internet which allows for easier navigation for the user. Without them we would have to search each web page we wanted to get the information from manually instead of a single click of a hyperlink.\n\n"
                +
                "We talked about the link types and the two different types that are absolute URLs and relative URLs which have different roles depending on what you want to do. The absolute URLs are designed to navigate the user to another website through directly identifying the full web address in the attribute. Whereas the relative URLs navigate the user anywhere within the same web page such as taking the user to the top of the web page when they are at the bottom.\n\n"
                +
                "Styling hyperlinks can allow us to visually enhance the appearance of our web page, through CSS you can customise the colour, font and the background of the hyperlinks to whatever you feel like. This functionality can help with accessibility for those who may have visual impairments and find it difficult to see the default hyperlink colour scheme. Accommodating to the user is a crucial factor in the overall user experience.\n\n"
                +
                "Finally, the different tags used in hyperlinks help with the functionality of the hyperlinks. For example, when you are linking a PDF document you need to include the < a > tag, followed by the file name and format for the hyperlink to be successful.");

        relativeLayout.addView(textView);
    }
}