package com.example.HTMLWizard;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.ImageView;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

import com.example.HTMLWizard.ImagesAndAudio.MultimediaIntro;
import com.example.HTMLWizard.bigquiz.WebpageStructureQ;
import com.example.HTMLWizard.headingsandtext.HeadingsIntro;
import com.example.HTMLWizard.htmlforms.HTMLFormsIntro;
import com.example.HTMLWizard.hyperlinksandanchors.HyperlinksIntro;
import com.example.HTMLWizard.listtypes.ListsIntro;
import com.example.HTMLWizard.tablesandttags.TableTagsIntro;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.example.HTMLWizard.simplehtmltags.TagsIntro;

public class LearnFragment extends Fragment {


    private ImageView imagesAndAudioView;
    private ImageView headingsAndTextView;
    private ImageView listTypesView;
    private ImageView tablesAndTagsView;
    private ImageView hyperlinksAndAnchorsView;
    private ImageView htmlFormsView;
    private ImageView bigQuizView;


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_learn, container, false);

        FirebaseDatabase database = FirebaseDatabase.getInstance();
        String userId = FirebaseAuth.getInstance().getCurrentUser().getUid();
        DatabaseReference databaseReference = database.getReference("users").child(userId).child("buttons");

        databaseReference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                for (DataSnapshot buttonSnapshot : dataSnapshot.getChildren()) {
                    String buttonId = buttonSnapshot.getKey();
                    boolean isEnabled = buttonSnapshot.getValue(Boolean.class);
                    Log.d("TAG", "Button ID: " + buttonId + ", isEnabled: " + isEnabled);
                    ImageButton button = view.findViewById(getResources().getIdentifier(buttonId, "id", getContext().getPackageName()));
                    button.setEnabled(isEnabled);
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                // Failed to read value
                Log.w("TAG", "Failed to read value.", error.toException());
            }
        });

        ImageView headingsAndTextView = view.findViewById(R.id.grey_ring_image_view2);

        databaseReference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if (dataSnapshot.hasChild("headings_and_text_start")) {

                    Boolean value = dataSnapshot.child("headings_and_text_start").getValue(Boolean.class);
                    if (value != null) {
                        if (value) {
                            headingsAndTextView.setImageResource(R.drawable.green_ring);
                        } else {
                            headingsAndTextView.setImageResource(R.drawable.grey_ring);
                        }
                        headingsAndTextView.setVisibility(View.VISIBLE);
                    }
                }
            }
            @Override
            public void onCancelled(@NonNull DatabaseError error) {

                Log.w("TAG", "Failed to read value.", error.toException());
            }
        });




            ImageView imagesAndAudioView = view.findViewById(R.id.grey_ring_image_view3);
            databaseReference.addValueEventListener(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                    if (dataSnapshot.hasChild("images_and_audio_start")) {
                        Boolean value = dataSnapshot.child("images_and_audio_start").getValue(Boolean.class);
                        if (value != null) {
                            if (value) {
                                imagesAndAudioView.setImageResource(R.drawable.green_ring);
                            } else {
                                imagesAndAudioView.setImageResource(R.drawable.grey_ring);
                            }
                            imagesAndAudioView.setVisibility(View.VISIBLE);
                        }
                    }
                }


            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Log.w("TAG", "Failed to read value.", error.toException());
            }
        });




        listTypesView = view.findViewById(R.id.grey_ring_image_view4);
        databaseReference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                boolean value = dataSnapshot.child("list_types_start").getValue(Boolean.class);
                if (value) {
                    listTypesView.setImageResource(R.drawable.green_ring);
                    listTypesView.setVisibility(View.VISIBLE);
                } else {
                    listTypesView.setImageResource(R.drawable.grey_ring);
                    listTypesView.setVisibility(View.VISIBLE);
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Log.w("TAG", "Failed to read value.", error.toException());
            }
        });


        tablesAndTagsView = view.findViewById(R.id.grey_ring_image_view5);
        databaseReference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                boolean value = dataSnapshot.child("tables_and_ttags_start").getValue(Boolean.class);
                if (value) {
                    tablesAndTagsView.setImageResource(R.drawable.green_ring);
                    tablesAndTagsView.setVisibility(View.VISIBLE);
                } else {
                    tablesAndTagsView.setImageResource(R.drawable.grey_ring);
                    tablesAndTagsView.setVisibility(View.VISIBLE);
                }
            }
            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Log.w("TAG", "Failed to read value.", error.toException());
            }
        });



        hyperlinksAndAnchorsView = view.findViewById(R.id.grey_ring_image_view6);
        databaseReference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                boolean value = dataSnapshot.child("hyperlinks_and_anchors_start").getValue(Boolean.class);
                if (value) {
                    hyperlinksAndAnchorsView.setImageResource(R.drawable.green_ring);
                    hyperlinksAndAnchorsView.setVisibility(View.VISIBLE);
                } else {
                    hyperlinksAndAnchorsView.setImageResource(R.drawable.grey_ring);
                    hyperlinksAndAnchorsView.setVisibility(View.VISIBLE);
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Log.w("TAG", "Failed to read value.", error.toException());
            }
        });


        htmlFormsView = view.findViewById(R.id.grey_ring_image_view7);
        databaseReference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                boolean value = dataSnapshot.child("html_forms_start").getValue(Boolean.class);
                if (value) {
                    htmlFormsView.setImageResource(R.drawable.green_ring);
                    htmlFormsView.setVisibility(View.VISIBLE);
                } else {
                    htmlFormsView.setImageResource(R.drawable.grey_ring);
                    htmlFormsView.setVisibility(View.VISIBLE);
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Log.w("TAG", "Failed to read value.", error.toException());
            }
        });


        bigQuizView = view.findViewById(R.id.grey_ring_image_view8);
        databaseReference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                boolean value = dataSnapshot.child("big_quiz_start").getValue(Boolean.class);
                if (value) {
                    bigQuizView.setImageResource(R.drawable.green_ring);
                    bigQuizView.setVisibility(View.VISIBLE);
                } else {
                    bigQuizView.setImageResource(R.drawable.grey_ring);
                    bigQuizView.setVisibility(View.VISIBLE);
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Log.w("TAG", "Failed to read value.", error.toException());
            }
        });


        ImageButton SHTstartButton = view.findViewById(R.id.simple_html_tags_start);
        SHTstartButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // When the button is clicked, navigate to TagsIntro activity
                Intent intent = new Intent(getActivity(), TagsIntro.class);
                startActivity(intent);
            }
        });

        ImageButton HATstartButton = view.findViewById(R.id.headings_and_text_start);
        HATstartButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getActivity(), HeadingsIntro.class);
                startActivity(intent);
            }
        });


        ImageButton IAAstartButton = view.findViewById(R.id.images_and_audio_start);
        IAAstartButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getActivity(), MultimediaIntro.class);
                startActivity(intent);
            }
        });


        ImageButton LTstartButton = view.findViewById(R.id.list_types_start);
        LTstartButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getActivity(), ListsIntro.class);
                startActivity(intent);
            }
        });

        ImageButton TATstartButton = view.findViewById(R.id.tables_and_ttags_start);
        TATstartButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getActivity(), TableTagsIntro.class);
                startActivity(intent);
            }
        });

        ImageButton HAstartButton = view.findViewById(R.id.hyperlinks_and_anchors_start);
        HAstartButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getActivity(), HyperlinksIntro.class);
                startActivity(intent);
            }
        });

        ImageButton HFstartButton = view.findViewById(R.id.html_forms_start);
        HFstartButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getActivity(), HTMLFormsIntro.class);
                startActivity(intent);
            }
        });

        ImageButton BQstartButton = view.findViewById(R.id.big_quiz_start);
        BQstartButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getActivity(), WebpageStructureQ.class);
                startActivity(intent);
            }
        });

        return view;
    }
}


