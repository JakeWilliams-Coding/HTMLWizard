package com.example.HTMLWizard.headingsandtext;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.DragEvent;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;


import com.example.HTMLWizard.R;


import androidx.appcompat.app.AppCompatActivity;

public class ArrangeHeadingsExercise extends AppCompatActivity {

    private TextView[] textViews;
    private RelativeLayout[] boxes;
    private Button mainSubmitButton;
    private ImageButton backArrowButton;
    private Button clearButton;

    private float[] originalXPositions;
    private float[] originalYPositions;
    private boolean isOriginalPositionsSet = false;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_arrange_headings_exercise);

        // Initialize TextViews
        textViews = new TextView[]{
                findViewById(R.id.textViewh1),
                findViewById(R.id.textViewh2),
                findViewById(R.id.textViewh3),
                findViewById(R.id.textViewh4),
                findViewById(R.id.textViewh5),
                findViewById(R.id.textViewh6)
        };

        // Initialize Boxes
        boxes = new RelativeLayout[]{
                findViewById(R.id.box1),
                findViewById(R.id.box2),
                findViewById(R.id.box3),
                findViewById(R.id.box4),
                findViewById(R.id.box5),
                findViewById(R.id.box6)
        };

        // Set onTouchListener to all TextViews
        for (TextView textView : textViews) {
            textView.setOnTouchListener(touchListener);
        }

        // Set onDragListener to all Boxes
        for (RelativeLayout box : boxes) {
            box.setOnDragListener(dragListener);
        }

        // Initialize nextButton
        mainSubmitButton = findViewById(R.id.submitButton);
        mainSubmitButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Check if all textViews are in the correct positions
                boolean isCorrect = areAllTextInCorrectBoxes();
                if (isCorrect) {
                    // Proceed to the next activity if everything is correct
                    startActivity(new Intent(com.example.HTMLWizard.headingsandtext.ArrangeHeadingsExercise.this, StylingText.class));
                } else {
                    // Display toast message if some answers are incorrect
                    Toast.makeText(com.example.HTMLWizard.headingsandtext.ArrangeHeadingsExercise.this, "Some answers are incorrect", Toast.LENGTH_SHORT).show();
                    // Log which TextViews are not in their correct boxes
                    for (int i = 0; i < textViews.length; i++) {
                        if (textViews[i].getParent() != boxes[i]) {
                            Log.d("ArrangeHeadingsExercise", "TextView " + (i+1) + " is not in the correct box");
                        }
                    }
                }
            }
        });


    // Initialize backArrowButton and set OnClickListener
    backArrowButton = findViewById(R.id.backArrow);
        backArrowButton.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            // Finish the current activity when the back arrow is clicked
            finish();
        }
    });

    // Initialize resetButton and set OnClickListener
    clearButton = findViewById(R.id.clearbutton);
        clearButton.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            // Reset TextViews positions
            resetTextViewsPositions();
        }
    });
}
    private void setOriginalPositions() {
        if (!isOriginalPositionsSet) {
            originalXPositions = new float[textViews.length];
            originalYPositions = new float[textViews.length];
            for (int i = 0; i < textViews.length; i++) {
                originalXPositions[i] = textViews[i].getX();
                originalYPositions[i] = textViews[i].getY();
            }
            isOriginalPositionsSet = true;
        }
    }

    private void resetTextViewsPositions() {
        setOriginalPositions(); // Ensure original positions are set
        for (int i = 0; i < textViews.length; i++) {
            textViews[i].setX(originalXPositions[i]);
            textViews[i].setY(originalYPositions[i]);
        }
    }

    private boolean areAllTextInCorrectBoxes() {
        for (int i = 0; i < textViews.length; i++) {
            TextView textView = textViews[i];
            RelativeLayout box = boxes[i];
            // Check if the center of the textView is within the bounds of the box
            int textViewCenterX = (int) (textView.getX() + textView.getWidth() / 2);
            int textViewCenterY = (int) (textView.getY() + textView.getHeight() / 2);
            if (!(textViewCenterX >= box.getLeft() && textViewCenterX <= box.getRight() &&
                    textViewCenterY >= box.getTop() && textViewCenterY <= box.getBottom())) {
                return false; // TextView is not in the correct box
            }
        }
        return true; // All TextViews are in the correct boxes
    }

    private final View.OnTouchListener touchListener = new View.OnTouchListener() {
        @Override
        public boolean onTouch(View v, MotionEvent event) {
            if (event.getAction() == MotionEvent.ACTION_DOWN) {
                View.DragShadowBuilder shadowBuilder = new View.DragShadowBuilder(v);
                v.startDragAndDrop(null, shadowBuilder, v, 0);
                setOriginalPositions(); // Update original positions when a TextView is touched
                return true;
            }
            return false;
        }
    };


    private final View.OnDragListener dragListener = new View.OnDragListener() {
        @Override
        public boolean onDrag(View v, DragEvent event) {
            int action = event.getAction();
            switch (action) {
                case DragEvent.ACTION_DROP:
                    View draggedView = (View) event.getLocalState();
                    RelativeLayout targetBox = (RelativeLayout) v;
                    // Calculate the center of the target box
                    int targetCenterX = targetBox.getLeft() + targetBox.getWidth() / 2;
                    int targetCenterY = targetBox.getTop() + targetBox.getHeight() / 2;
                    // Set the position of the dragged TextView to the center of the target box
                    draggedView.setX(targetCenterX - draggedView.getWidth() / 2);
                    draggedView.setY(targetCenterY - draggedView.getHeight() / 2);
                    break;
            }
            return true;
        }
    };
}

