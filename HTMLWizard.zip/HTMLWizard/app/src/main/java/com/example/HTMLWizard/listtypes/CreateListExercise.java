package com.example.HTMLWizard.listtypes;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import com.example.HTMLWizard.R;


public class CreateListExercise extends AppCompatActivity {

    private WebView htmlPlayground;
    private TextView task1, task2, task3;
    private StringBuilder htmlContentBuilder;
    private ImageButton nextButton;
    private Button clearButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_list_exercise);

        htmlPlayground = findViewById(R.id.htmlPlayground);
        task1 = findViewById(R.id.task1);
        task2 = findViewById(R.id.task2);
        task3 = findViewById(R.id.task3);
        nextButton = findViewById(R.id.html_intro_1);
        clearButton = findViewById(R.id.clearbutton);

        htmlPlayground.setWebViewClient(new WebViewClient());
        htmlPlayground.getSettings().setJavaScriptEnabled(true);

        htmlContentBuilder = new StringBuilder();

        setupTextView(task1, "<");
        setupTextView(task2, "Hello World");
        setupTextView(task3, "/>");

        nextButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (isCorrectOrder()) {
                    startActivity(new Intent(com.example.HTMLWizard.listtypes.CreateListExercise.this, NestedLists.class));
                    finish();
                } else {
                    Toast.makeText(com.example.HTMLWizard.listtypes.CreateListExercise.this, "Incorrect order!", Toast.LENGTH_SHORT).show();
                }
            }
        });

        clearButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                htmlPlayground.loadData("", "text/html", null);
                htmlContentBuilder.setLength(0);
            }
        });
    }

    private void setupTextView(final TextView textView, final String text) {
        textView.setText(text);
        textView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                addToHtmlPlayground(textView);
            }
        });
    }

    private void addToHtmlPlayground(TextView textView) {
        htmlContentBuilder.append(textView.getText()).append(" ");
        htmlPlayground.loadDataWithBaseURL(null, htmlContentBuilder.toString(), "text/html", "UTF-8", null);
    }
    private boolean isCorrectOrder() {
        String expectedOrder = "< Hello World />";
        String currentOrder = htmlContentBuilder.toString().trim();
        return currentOrder.equals(expectedOrder);
    }
}