package com.example.HTMLWizard.listtypes;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.example.HTMLWizard.MainActivity;
import com.example.HTMLWizard.R;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class ConclusionLT extends AppCompatActivity {

    ImageButton html_intro_1;
    RelativeLayout relativeLayout;
    DatabaseReference databaseReference;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.base_activity_layout);


        databaseReference = FirebaseDatabase.getInstance().getReference("buttons");

        html_intro_1 = findViewById(R.id.html_intro_1);

        html_intro_1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                databaseReference.child("tables_and_ttags_start").setValue(true);
                Intent intent = new Intent(ConclusionLT.this, MainActivity.class);
                startActivity(intent);
            }
        });
        relativeLayout = findViewById(R.id.lesson_text);


        TextView textView = new TextView(this);
        textView.setLayoutParams(new RelativeLayout.LayoutParams(
                RelativeLayout.LayoutParams.WRAP_CONTENT,
                RelativeLayout.LayoutParams.WRAP_CONTENT));

        textView.setText("To conclude this lesson, lists are essential for organising content in a hierarchical structure on a web page. When text is in a list instead of on separate lines on the web page it makes the user interface look more professional and tidy with the use of lists.\n"
                +
                "There are two common list types, ordered lists and unordered lists. They both have their uses in different situations, ordered lists will create a list with a number on the left hand side of the text indicating there is an order to the list items you have included. An unordered list will just have bullet points instead, therefore meaning there is not an order to the list and they could have been included in any order.\n"
                +
                "You can use a combination of the two lists and therefore make it a nested list, this is when you place a list within another list. It indicates sub categories of a list which improves content organisation.\n"
                +
                "The addition of < div > elements makes a flexible container for organising your lists which helps create a professional layout. They allow you to include headers, footers and sidebars which is helpful for the overall layout customisation.");

        relativeLayout.addView(textView);
    }
}