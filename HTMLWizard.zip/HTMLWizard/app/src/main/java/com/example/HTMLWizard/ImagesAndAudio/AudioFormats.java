package com.example.HTMLWizard.ImagesAndAudio;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.example.HTMLWizard.R;

public class AudioFormats extends AppCompatActivity {

    ImageButton html_intro_1;
    RelativeLayout relativeLayout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.base_activity_layout);

        html_intro_1 = findViewById(R.id.html_intro_1);

        html_intro_1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(com.example.HTMLWizard.ImagesAndAudio.AudioFormats.this, AudioFormatExercise.class);
                startActivity(intent);
            }
        });


        relativeLayout = findViewById(R.id.lesson_text);


        TextView textView = new TextView(this);
        textView.setLayoutParams(new RelativeLayout.LayoutParams(
                RelativeLayout.LayoutParams.WRAP_CONTENT,
                RelativeLayout.LayoutParams.WRAP_CONTENT));

        textView.setTextColor(ContextCompat.getColor(this, R.color.textColor));

        textView.setText("In digital audio there are different formats which have different purposes, it is dependent on operating system support and browser compatibility. But there are 2 common audio formats that are used on a web page, they are MP3 and WAV.\n\n"
                +
                "MP3: This is the more common of the two audio formats as it has a high compression rate which means small file sizes without detrimental audio quality loss. It is supported by most browsers, so it is ideal for most developers' usage.\n\n"
                +
                "WAV: This audio format is uncompressed, meaning it maintains the original quality of the audio which in some cases could be superior audio quality. This does come with some downsides though, due to the increased quality it means larger file sizes which affects the loading speed on the web page. If the user has a poor internet connection then it may fail to load audio formatted with WAV. Its browser support is more limited than MP3 too as it may require specific plugins to be able to work.\n\n"
                +
                "When developers are integrating audio into a web page they need to consider the browser compatibility. We need to think of fallback options for a broader support over any device, one solution is making sure it has cross-browser compatibility. So regardless of the browser the user is accessing the web page from, it still should be able to play the audio. Some users may have internet connectivity issues which can affect the audio from playing, the fallback options should allow the user to download the audio file so they can play it offline. As stated in a previous lesson the accessibility is also an issue, users with hearing impairment should have access to audio content in a suitable format such as audio description.");

        relativeLayout.addView(textView);
    }
}