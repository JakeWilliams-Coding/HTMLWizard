package com.example.HTMLWizard.htmlforms;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.example.HTMLWizard.R;

public class CommonAttributes extends AppCompatActivity {

    ImageButton html_intro_1;
    RelativeLayout relativeLayout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.base_activity_layout);

        html_intro_1 = findViewById(R.id.html_intro_1);

        html_intro_1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(com.example.HTMLWizard.htmlforms.CommonAttributes.this, ButtonElements.class);
                startActivity(intent);
            }
        });


        relativeLayout = findViewById(R.id.lesson_text);


        TextView textView = new TextView(this);
        textView.setLayoutParams(new RelativeLayout.LayoutParams(
                RelativeLayout.LayoutParams.WRAP_CONTENT,
                RelativeLayout.LayoutParams.WRAP_CONTENT));

        textView.setText("Type Attribute: Purpose: It defines the type of input control that is going to be used. Depending on the type attribute it can change how the input field appears. For example it can be just a regular text input or it can be checkboxes. The typer affected the appearance of the text input and also how it behaves for the user. Here is an example of this: < input type= &quot; text &quot; >.\n\n"
                +
                "Name Attribute: Purpose: This attribute will assign a name to the input control being used, it helps with identifying what data has been submitted to the server. The name of the attribute is like a key and what the user inputs is a value. Each of the form elements should have a unique identifier so they do not get mixed up. An example of this is as shown: < input type= &quot; text &quot; name= &quot; username &quot; >.\n\n"
                +
                "Placeholder Attribute: Purpose: This attribute gives the user a hint in the input field to remind them the task they are trying to achieve. The hint text is normally a light grey colour emphasising it is not solid text and can be edited by the user. A placeholder enhances overall user experience because it provides context to what details need to be inputted into the field. Here is an example: < input type= &quot; text &quot; placeholder= &quot; Enter your username &quot; >.\n\n"
                +
                "Value Attribute:  Purpose: This attribute sets the initial value of the input control and will auto-fill the input field with a standard default value. This default value can be left how it is, or the user can change it if they want to. As developers we commonly use this attribute within text input fields, checkboxes and radio buttons where there is a default value provided. An example of this attribute in use can be: < input type=&quot; radio &quot; name=&quot; gender &quot; value=&quot; male &quot; >");

        relativeLayout.addView(textView);
    }
}