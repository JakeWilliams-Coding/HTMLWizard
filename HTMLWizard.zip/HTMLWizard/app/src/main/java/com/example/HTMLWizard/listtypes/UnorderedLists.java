package com.example.HTMLWizard.listtypes;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.example.HTMLWizard.R;

public class UnorderedLists extends AppCompatActivity {

    ImageButton html_intro_1;
    RelativeLayout relativeLayout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.base_activity_layout);

        html_intro_1 = findViewById(R.id.html_intro_1);

        html_intro_1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(com.example.HTMLWizard.listtypes.UnorderedLists.this, NestedLists.class);
                startActivity(intent);
            }
        });

        relativeLayout = findViewById(R.id.lesson_text);


        TextView textView = new TextView(this);
        textView.setLayoutParams(new RelativeLayout.LayoutParams(
                RelativeLayout.LayoutParams.WRAP_CONTENT,
                RelativeLayout.LayoutParams.WRAP_CONTENT));

        textView.setText("Unordered Lists: This type of lists is represented through the < ul > tag. The name may be deceiving because it does not mean your list items will be in a random order, it just means there will not be numbers along the side. It will be replaced with bullet points instead, it indicates there isn’t a specified order for the text items you have included. Similarly to the < ol > we need to include the < li > tags in order to show the text on the web page. Below is an example of how you can use the < ul > tag:\n\n" +
                "\n" +
                "< ul >\n" +
                "  < li > Unordered < /li >\n" +
                "  < li  > List < /li >\n" +
                "  < li >Tag < /li >\n" +
                "< /ul >\n");

        relativeLayout.addView(textView);
    }
}