package com.example.HTMLWizard.headingsandtext;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.example.HTMLWizard.R;


public class ApplyStylesToText extends AppCompatActivity {

    private TextView task1, task2, task3, task4;
    private StringBuilder htmlContentBuilder;
    private Button mainSubmitButton;
    private Button clearButton;
    private ImageButton backArrowButton;
    private LinearLayout taskContainer;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_apply_styles_to_text);


        task1 = findViewById(R.id.task1);
        task2 = findViewById(R.id.task2);
        task3 = findViewById(R.id.task3);
        task4 = findViewById(R.id.task4);
        mainSubmitButton = findViewById(R.id.submitButton);
        backArrowButton = findViewById(R.id.backArrow);
        clearButton = findViewById(R.id.clearbutton);
        taskContainer = findViewById(R.id.taskContainer);


        htmlContentBuilder = new StringBuilder();


        setupTextView(task1, "{");
        setupTextView(task2, "p");
        setupTextView(task3, "}");
        setupTextView(task4, "color:#000");


        mainSubmitButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (isCorrectOrder()) {
                    startActivity(new Intent(ApplyStylesToText.this, ListAndHeadings.class));
                    finish();
                } else {
                    Toast.makeText(ApplyStylesToText.this, "Incorrect order!", Toast.LENGTH_SHORT).show();
                }
            }
        });

        clearButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Clear the StringBuilder
                htmlContentBuilder.setLength(0);
                // Clear task container
                taskContainer.removeAllViews();
            }
        });

        backArrowButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }


    private void setupTextView(final TextView textView, final String text) {
        textView.setText(text);
        textView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                addToTaskContainer(textView);
            }
        });
    }


    private void addToTaskContainer(TextView textView) {

        TextView taskView = new TextView(this);
        taskView.setText(textView.getText());

        // Set layout parameters for margin
        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
        );

        if (taskContainer.getChildCount() == 0) {
            layoutParams.setMargins(50, 0, 0, 0);
        } else {
            layoutParams.setMargins(10, 0, 0, 0);
        }

        taskView.setLayoutParams(layoutParams);

        taskContainer.addView(taskView);

        taskContainer.setGravity(Gravity.CENTER_VERTICAL);
    }


    private boolean isCorrectOrder() {
        String expectedOrder = "p{color:#000}";

        StringBuilder currentOrderBuilder = new StringBuilder();
        for (int i = 0; i < taskContainer.getChildCount(); i++) {
            View child = taskContainer.getChildAt(i);
            if (child instanceof TextView) {
                currentOrderBuilder.append(((TextView) child).getText());
            }
        }
        String currentOrder = currentOrderBuilder.toString().trim();

        return currentOrder.equals(expectedOrder);
    }

}