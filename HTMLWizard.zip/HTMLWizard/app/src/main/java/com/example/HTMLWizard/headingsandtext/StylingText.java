package com.example.HTMLWizard.headingsandtext;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.example.HTMLWizard.R;

public class StylingText extends AppCompatActivity {

    ImageButton html_intro_1;
    RelativeLayout relativeLayout;

    private ImageButton backArrowButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.base_activity_layout);

        html_intro_1 = findViewById(R.id.html_intro_1);

        html_intro_1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(com.example.HTMLWizard.headingsandtext.StylingText.this, TextFormattingTags.class);
                startActivity(intent);
            }
        });


        backArrowButton = findViewById(R.id.backArrow);
        backArrowButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        relativeLayout = findViewById(R.id.lesson_text);


        TextView textView = new TextView(this);
        textView.setLayoutParams(new RelativeLayout.LayoutParams(
                RelativeLayout.LayoutParams.WRAP_CONTENT,
                RelativeLayout.LayoutParams.WRAP_CONTENT));

        textView.setTextColor(ContextCompat.getColor(this, R.color.textColor));

        textView.setText("CSS (Cascading Style Sheets) is a stylesheet language used to describe the presentation of a document written in HTML or XML. CSS allows developers to control the appearance of elements on a webpage, including text, by specifying various properties such as color, font size, font family, alignment, and more.\n\n"
                +
                "An example piece of code of a CSS style for font can be this - body {\n" +
                "      font-family: Arial, sans-serif; /* Set font family for the entire document */\n" +
                "    }\n\n"

                +
                "Alternatively, you can apply styles inline directly within HTML elements. Here's an example of inline styling: <p style=\"color: red; font-family: 'Times New Roman', serif;\">This is a paragraph of text with inline styles.</p>");

        relativeLayout.addView(textView);
    }
}
