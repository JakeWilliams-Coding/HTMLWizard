package com.example.HTMLWizard;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.MenuItem;

import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.navigation.NavigationBarView;

public class MainActivity extends AppCompatActivity {

    BottomNavigationView bottomNavigationView;

    LearnFragment learnFragment = new LearnFragment();
    NotesFragment notesFragment = new NotesFragment();
    MyprofileFragment myprofileFragment = new MyprofileFragment();

    ChatbotFragment chatbotFragment = new ChatbotFragment();


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        bottomNavigationView  = findViewById(R.id.bottom_navigation);

        getSupportFragmentManager().beginTransaction().replace(R.id.container,learnFragment).commit();

        bottomNavigationView.setOnItemSelectedListener(new NavigationBarView.OnItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(MenuItem item) {
                if (item.getItemId() == R.id.learn) {
                    getSupportFragmentManager().beginTransaction().replace(R.id.container, learnFragment).commit();
                    return true;
                } else if (item.getItemId() == R.id.chatbot) {
                    getSupportFragmentManager().beginTransaction().replace(R.id.container, chatbotFragment).commit();
                    return true;
                } else if (item.getItemId() == R.id.notes) {
                    getSupportFragmentManager().beginTransaction().replace(R.id.container, notesFragment).commit();
                    return true;
                } else if (item.getItemId() == R.id.myprofile) {
                    getSupportFragmentManager().beginTransaction().replace(R.id.container, myprofileFragment).commit();
                    return true;
            }

                return false;
            }


        });

    }
}