package com.example.HTMLWizard.ImagesAndAudio;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.HTMLWizard.R;



public class AudioAttributesExercise extends AppCompatActivity {
    private TextView questionTextView;
    private RadioGroup radioGroup;
    private Button submitButton;
    private int questionIndex = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_audio_attributes_exercise);

        questionTextView = findViewById(R.id.questionTextView);
        radioGroup = findViewById(R.id.radioGroup);
        submitButton = findViewById(R.id.submitButton);

        displayQuestion(questionIndex);

        submitButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                checkAnswer();
            }
        });
    }

    private void displayQuestion(int questionIndex) {
        questionTextView.setText(QuestionAnswerIA.question[questionIndex]);

        radioGroup.removeAllViews();
        for (int i = 0; i < QuestionAnswerIA.choices[questionIndex].length; i++) {
            RadioButton radioButton = new RadioButton(this);
            radioButton.setText(QuestionAnswerIA.choices[questionIndex][i]);
            radioGroup.addView(radioButton);
        }
    }

    private void checkAnswer() {
        int selectedRadioButtonId = radioGroup.getCheckedRadioButtonId();

        if (selectedRadioButtonId != -1) {
            RadioButton selectedRadioButton = findViewById(selectedRadioButtonId);
            String selectedAnswer = selectedRadioButton.getText().toString();

            if (selectedAnswer.equals(QuestionAnswerIA.correctAnswers[questionIndex])) {
                Intent intent = new Intent(this, AudioFormats.class);
                startActivity(intent);
            } else {
                Toast.makeText(this, "Incorrect Answer", Toast.LENGTH_SHORT).show();
            }
        } else {
            Toast.makeText(this, "Please select an answer", Toast.LENGTH_SHORT).show();
        }
    }
}
