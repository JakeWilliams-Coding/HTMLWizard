package com.example.HTMLWizard.headingsandtext;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import com.example.HTMLWizard.MainActivity;
import com.example.HTMLWizard.R;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class ConclusionHT extends AppCompatActivity {

    ImageButton html_intro_1;
    RelativeLayout relativeLayout;
    DatabaseReference databaseReference;

    private ImageButton backArrowButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.base_activity_layout);

        FirebaseDatabase database = FirebaseDatabase.getInstance();

        String userId = FirebaseAuth.getInstance().getCurrentUser().getUid();

        databaseReference = database.getReference("users").child(userId).child("buttons");


        html_intro_1 = findViewById(R.id.html_intro_1);


        html_intro_1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                databaseReference.child("images_and_audio_start").setValue(true);
                Intent intent = new Intent(ConclusionHT.this, MainActivity.class);
                startActivity(intent);
            }
        });


        backArrowButton = findViewById(R.id.backArrow);
        backArrowButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        relativeLayout = findViewById(R.id.lesson_text);

        TextView textView = new TextView(this);
        textView.setLayoutParams(new RelativeLayout.LayoutParams(
                RelativeLayout.LayoutParams.WRAP_CONTENT,
                RelativeLayout.LayoutParams.WRAP_CONTENT));

        textView.setTextColor(ContextCompat.getColor(this, R.color.textColor));


        textView.setText("To finish this lesson here's a quick recap of the key points learnt. I encourage you to play around with the different elements to grasp everything for yourself.\n\n"
                +
                "HTML Headings: Importance: Headings are crucial for structuring webpages, aiding in navigation, accessibility, and SEO. Hierarchy: HTML provides six levels of headings (<h1> to <h6>), with <h1> being the most important and <h6> the least.\n\n"
                +
                "Basic Text Elements: HTML elements like <p>, <em>, <strong>, <span>, and <br> are essential for structuring and styling text content. Each element serves a specific purpose, such as defining paragraphs, emphasizing text, applying inline styling, and inserting line breaks.\n\n"
                +
                "CSS Text Styling: CSS (Cascading Style Sheets) is used to style text and control its appearance on webpages. Styles can be applied inline within HTML elements or through external stylesheets, allowing for customization of text color, font, size, etc.\n\n"
                +
                "Additional Text Formatting Tags: Tags like <mark>, <sub>, <sup>, and <blockquote> offer additional options for text formatting and presentation. They can be used to highlight text, indicate subscript/superscript, and format quotations, respectively.\n\n"
                +
                "Relationship between Headings and Lists: Headings can be used to structure content within lists by providing descriptive titles for each list section. They help organize list items hierarchically, improving readability and comprehension.");


        relativeLayout.addView(textView);

    }
}

