package com.example.HTMLWizard.headingsandtext;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.example.HTMLWizard.R;

public class TextElements extends AppCompatActivity {

    ImageButton html_intro_1;
    RelativeLayout relativeLayout;

    private ImageButton backArrowButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.base_activity_layout);

        html_intro_1 = findViewById(R.id.html_intro_1);

        html_intro_1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(com.example.HTMLWizard.headingsandtext.TextElements.this, ArrangeHeadingsExercise.class);
                startActivity(intent);
            }
        });

        backArrowButton = findViewById(R.id.backArrow);
        backArrowButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        relativeLayout = findViewById(R.id.lesson_text);


        TextView textView = new TextView(this);
        textView.setLayoutParams(new RelativeLayout.LayoutParams(
                RelativeLayout.LayoutParams.WRAP_CONTENT,
                RelativeLayout.LayoutParams.WRAP_CONTENT));

        textView.setTextColor(ContextCompat.getColor(this, R.color.textColor));

        textView.setText("Text elements in HTML refer to the various tags or elements used to structure and present textual content within a web page. These elements allow developers to define the structure, semantics, and formatting of text on a webpage. Text elements encompass a wide range of tags that include those used for defining paragraphs, emphasizing text, creating lists, inserting line breaks, and more.\n\n"
                +
                "<p> (Paragraph):Purpose: The <p> element is used to define a paragraph of text. It represents a block of text that is typically separated from adjacent content by vertical spacing. Impact on Text Presentation: <p> elements are commonly used to structure textual content into coherent paragraphs, making it easier for users to read and understand.\n\n"
                +
                "<strong> (Strong Emphasis):Purpose: The <strong> element is used to denote text that has strong importance, importance that is typically stylistically different from the surrounding text. By default, browsers usually render strong text in bold. Impact on Text Presentation: <strong> is often used to highlight important keywords, phrases, or sections within a document, indicating their significance to the reader.\n\n"
                +
                "<br> (Line Break): Purpose: The <br> element is used to insert a line break within text content. Unlike paragraphs (<p>), which create a block of text, <b> simply breaks the line and continues the text flow on the next line. Impact on Text Presentation: <br> is handy for creating simple line breaks within text, such as in addresses or poetry, where line breaks are important for the presentation.\n\n"
                +
                "<span>: Purpose: The <span> element is a generic inline container that does not inherently change the appearance of the text it contains. It is often used to apply styles or manipulate specific portions of text via CSS or JavaScript. Impact on Text Presentation: <span> allows developers to target specific sections of text for styling or scripting purposes without affecting the overall structure of the document.");

        relativeLayout.addView(textView);
    }
}