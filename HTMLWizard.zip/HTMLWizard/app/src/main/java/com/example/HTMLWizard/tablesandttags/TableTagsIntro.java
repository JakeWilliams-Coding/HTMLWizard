package com.example.HTMLWizard.tablesandttags;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.example.HTMLWizard.R;

public class TableTagsIntro extends AppCompatActivity {

    ImageButton html_intro_1;
    RelativeLayout relativeLayout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.base_activity_layout);

        html_intro_1 = findViewById(R.id.html_intro_1);
        html_intro_1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(com.example.HTMLWizard.tablesandttags.TableTagsIntro.this, TableStructure.class);
                startActivity(intent);
            }
        });
        relativeLayout = findViewById(R.id.lesson_text);

        TextView textView = new TextView(this);
        textView.setLayoutParams(new RelativeLayout.LayoutParams(
                RelativeLayout.LayoutParams.WRAP_CONTENT,
                RelativeLayout.LayoutParams.WRAP_CONTENT));

        textView.setText("Tables are a vital piece of HTML so we can present data in a tidy and professional manner on a web page. They give us a pre-structured layout in which we can arrange any information we want into them. They are used commonly for websites where data comparison is important such as e-commerce websites or business analytics etc.\n\n"
                +
                "The use of tables gives up precise alignment on a web page and will format with the data in a simple way to read and understand. As a developer, you can control where you want certain text placed or any other content with the table items. It is easy to specify where you want your data and how you want it to be presented to a user.\n\n"
                +
                "Responsive tables allow us to adapt to any screen size a user may be viewing the website on. If we input a strict height and width of the table then on some displays it may look perfect  but other displays such as mobile devices, then the table would be too large to see on the screen at the same time. So having a table which adapts to the size of the user's display enhances the user experience.\n\n"
                +
                "Screen readers and other assistive technologies can also be used on tables, which means we can still have structure to our web page whilst also providing the accessibility to users who need it. Adding context to the tables in order to help with the screen readers are essential in order to convey the information in the correct manner. It provides the screen reader with context which will help with the structure it reads the words.\n\n"
                +
                "Common scenarios where tables are commonly used on web pages include:Data Grids, Timetables, Product comparisons etc.\n");

        relativeLayout.addView(textView);
    }
}