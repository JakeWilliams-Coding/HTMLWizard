package com.example.HTMLWizard.listtypes;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.example.HTMLWizard.R;

public class ListsIntro extends AppCompatActivity {

    ImageButton html_intro_1;
    RelativeLayout relativeLayout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.base_activity_layout);

        html_intro_1 = findViewById(R.id.html_intro_1);

        html_intro_1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(com.example.HTMLWizard.listtypes.ListsIntro.this, OrderedLists.class);
                startActivity(intent);
            }
        });

        relativeLayout = findViewById(R.id.lesson_text);


        TextView textView = new TextView(this);
        textView.setLayoutParams(new RelativeLayout.LayoutParams(
                RelativeLayout.LayoutParams.WRAP_CONTENT,
                RelativeLayout.LayoutParams.WRAP_CONTENT));

        textView.setText("When we are developing in HTML we can use lists to organise and structure the content we have included in our web page. So we can use lists to organise our content in a hierarchical structure to choose where we want each piece of content to be on the web page. There are 2 types of lists we can use in order to do this, there are ordered lists and unordered lists. Developers will use a combination of these list types to achieve a professional looking user interface.\n");

        relativeLayout.addView(textView);
    }
}