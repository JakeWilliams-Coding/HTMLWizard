package com.example.HTMLWizard.bigquiz;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import com.example.HTMLWizard.MainActivity;
import com.example.HTMLWizard.R;
import com.example.HTMLWizard.simplehtmltags.QuestionAnswerSH;

public class tableRowTagQ extends AppCompatActivity {
    private EditText answerEditText;
    private Button checkButton;
    private ImageButton backArrowButton;

    private TextView questionTextView2;


    private int questionIndex = 3;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_table_row_tag_q);

        answerEditText = findViewById(R.id.answerEditText);
        checkButton = findViewById(R.id.checkButton);
        backArrowButton = findViewById(R.id.backArrow);



        checkButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                checkAnswer();
            }
        });



        backArrowButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });


    }

    private void checkAnswer() {
        String userAnswer = answerEditText.getText().toString().trim();
        String correctAnswer = QuestionAnswerSH.correctAnswers[questionIndex];

        if (userAnswer.equals(correctAnswer)) {
            questionIndex++;
            if (questionIndex < QuestionAnswerSH.question.length) {
                answerEditText.setText("");
                displayQuestion(questionIndex);
            } else {
                Intent intent = new Intent(tableRowTagQ.this, aTagQ.class);
                startActivity(intent);
            }
        } else {
            Toast.makeText(this, "Incorrect Answer", Toast.LENGTH_SHORT).show();
        }
    }

    private void displayQuestion(int questionIndex) {
        if (questionIndex < QuestionAnswerBQ.question.length) {
            questionTextView2.setText(QuestionAnswerBQ.question[questionIndex]);
        }
    }
}