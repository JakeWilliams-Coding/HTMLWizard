package com.example.HTMLWizard.simplehtmltags;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.HTMLWizard.R;

public class InteractiveQuizPt3 extends AppCompatActivity {
    private TextView questionTextView;
    private RadioGroup radioGroup;
    private Button submitButton;
    private ImageButton backArrowButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_interactive_quiz_pt3);

        questionTextView = findViewById(R.id.questionTextView);
        radioGroup = findViewById(R.id.radioGroup);
        submitButton = findViewById(R.id.submitButton);
        backArrowButton = findViewById(R.id.backArrow);

        displayQuestion(2);

        submitButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                checkAnswer();
            }
        });

        backArrowButton = findViewById(R.id.backArrow);
        backArrowButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

    }

    private void displayQuestion(int questionIndex) {
        questionTextView.setText(QuestionAnswerSH.question[questionIndex]);

        radioGroup.removeAllViews();
        for (int i = 0; i < QuestionAnswerSH.choices[questionIndex].length; i++) {
            RadioButton radioButton = new RadioButton(this);
            radioButton.setText(QuestionAnswerSH.choices[questionIndex][i]);
            radioGroup.addView(radioButton);
        }
    }

    private void checkAnswer() {
        int selectedRadioButtonId = radioGroup.getCheckedRadioButtonId();

        if (selectedRadioButtonId != -1) {
            RadioButton selectedRadioButton = findViewById(selectedRadioButtonId);
            String selectedAnswer = selectedRadioButton.getText().toString();

            if (selectedAnswer.equals(QuestionAnswerSH.correctAnswers[2])) {
                Intent intent = new Intent(this, HTMLcomments.class);
                startActivity(intent);
            } else {
                Toast.makeText(this, "Incorrect Answer", Toast.LENGTH_SHORT).show();
            }
        } else {
            Toast.makeText(this, "Please select an answer", Toast.LENGTH_SHORT).show();
        }
    }
}