package com.example.HTMLWizard.bigquiz;

public class QuestionAnswerBQ {


    public static String question[] ={
            "What is the purpose of HTML tags in webpage structure?",
            "Which HTML tag is used to contain the main content of a webpage?",
            "In HTML, what attribute provides an alternate text for an image?",
            "Which HTML tag is used to define a table row?",
            "What is the significance of the <a> tag in HTML?",
            "What CSS property can be used to style and format <div> elements?",
            "What does the colspan attribute do in an HTML table?",
            "Which HTML tag is used to define the main heading of a webpage?"
    };

    public static String choices[][] = {
            {"To execute JavaScript functions","To organize and structure content"," To enhance visual design","To embed multimedia elements"},
            {"<body>"},
            {"caption","alt"," title","description"},
            {"<table>","<tr>","<th>","<td>"},
            {"It defines an image element","It creates a form input field","It is used to create hyperlinks","It styles text in italics"},
            {"visibility","transform","layout","display"},
            {" Merges cells horizontally","Adds a border around the table","Defines the table's caption","Controls the width of the table"},
            {" <header>","<title>","<h1>","<main>"}
    };

    public static String correctAnswers[] = {
            "To organize and structure content",
            "<body>",
            "alt",
            "<tr>",
            "It is used to create hyperlinks",
            "display",
            "Merges cells horizontally",
            "<h1>",
    };

}
