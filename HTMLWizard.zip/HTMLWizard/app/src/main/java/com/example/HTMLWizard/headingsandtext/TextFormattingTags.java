package com.example.HTMLWizard.headingsandtext;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.example.HTMLWizard.R;

public class TextFormattingTags extends AppCompatActivity {

    ImageButton html_intro_1;
    RelativeLayout relativeLayout;

    private ImageButton backArrowButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.base_activity_layout);

        html_intro_1 = findViewById(R.id.html_intro_1);

        html_intro_1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(com.example.HTMLWizard.headingsandtext.TextFormattingTags.this, ApplyStylesToText.class);
                startActivity(intent);
            }
        });

        backArrowButton = findViewById(R.id.backArrow);
        backArrowButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        relativeLayout = findViewById(R.id.lesson_text);


        TextView textView = new TextView(this);
        textView.setLayoutParams(new RelativeLayout.LayoutParams(
                RelativeLayout.LayoutParams.WRAP_CONTENT,
                RelativeLayout.LayoutParams.WRAP_CONTENT));

        textView.setTextColor(ContextCompat.getColor(this, R.color.textColor));

        textView.setText("There are a few more tags which help present your content on the web-page\n\n"
                +
                "<mark>: Purpose: The <mark> element is used to highlight or mark portions of text, typically to indicate relevance or highlight search results. Usage: It's commonly used when you want to visually distinguish certain words or phrases within a block of text. For example, when displaying search results, you can use <mark> to highlight the search terms within the content.\n\n"
                +
                "<sub> and <sup>: <sub>: Stands for subscript. It is used to render text as subscript, meaning it appears slightly below the baseline of the surrounding text. <sup>: Stands for superscript. It is used to render text as superscript, meaning it appears slightly above the baseline of the surrounding text. Usage: These elements are often used in mathematical expressions, chemical formulas, footnotes, and references where smaller text is required either above or below the main text.\n\n"
                +
                "<blockquote>;: Purpose: The <blockquote> element is used to indicate that the enclosed text is a longer quotation extracted from another source. Usage: It's typically used to visually distinguish quoted text from the surrounding content. Browsers usually render <blockquote> with indentation or other styling to differentiate it from regular paragraphs.");

        relativeLayout.addView(textView);
    }
}
