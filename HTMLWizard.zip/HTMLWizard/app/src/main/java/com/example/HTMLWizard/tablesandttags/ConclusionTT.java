package com.example.HTMLWizard.tablesandttags;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.example.HTMLWizard.MainActivity;
import com.example.HTMLWizard.R;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class ConclusionTT extends AppCompatActivity {

    ImageButton html_intro_1;
    RelativeLayout relativeLayout;
    DatabaseReference databaseReference;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.base_activity_layout);


        databaseReference = FirebaseDatabase.getInstance().getReference("buttons");


        html_intro_1 = findViewById(R.id.html_intro_1);
        html_intro_1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                databaseReference.child("hyperlinks_and_anchors_start").setValue(true);
                Intent intent = new Intent(ConclusionTT.this, MainActivity.class);
                startActivity(intent);
            }
        });

        relativeLayout = findViewById(R.id.lesson_text);

        TextView textView = new TextView(this);
        textView.setLayoutParams(new RelativeLayout.LayoutParams(
                RelativeLayout.LayoutParams.WRAP_CONTENT,
                RelativeLayout.LayoutParams.WRAP_CONTENT));

        textView.setText("To conclude this lesson we have learnt that tables are important for presenting data on a web page in a systematic way. You will find these elements commonly in e-commerce websites or any data comparison websites where organised data is important for the user's experience.\n\n"
                +
                "We can programme these tables to be responsive and cater to any screen size, this allows us as developers to control how our content looks on the screen. When using the responsive tables we give a percentage of how much of the parent container we want it to take up.\n\n"
                +
                "We have learnt the common attributes used to make a table in HTML, they include < table >, < tr >, < th >, and < td >. This forms the basic structure of our table as it provides the columns and rows for inserting our data.\n\n"
                +
                "CSS allows us to style tables however we want them to look, customisation such as changing the background colour of the table or adding a margin to the outside so it has more space around the edge is a prime example. The default design of a table doesn’t look appealing or very professional so enhancing this makes all the difference.");

        relativeLayout.addView(textView);
    }
}