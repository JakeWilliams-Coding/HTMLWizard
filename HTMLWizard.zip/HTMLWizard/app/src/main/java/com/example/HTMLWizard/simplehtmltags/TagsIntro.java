package com.example.HTMLWizard.simplehtmltags;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.example.HTMLWizard.R;

public class TagsIntro extends AppCompatActivity {

    ImageButton html_intro_1;
    RelativeLayout relativeLayout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.base_activity_layout);

        html_intro_1 = findViewById(R.id.html_intro_1);
        html_intro_1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(TagsIntro.this, CommonTags.class);
                startActivity(intent);
            }
        });


        relativeLayout = findViewById(R.id.lesson_text);

        TextView textView = new TextView(this);
        textView.setLayoutParams(new RelativeLayout.LayoutParams(
                RelativeLayout.LayoutParams.WRAP_CONTENT,
                RelativeLayout.LayoutParams.WRAP_CONTENT));

        textView.setTextColor(ContextCompat.getColor(this, R.color.textColor));


        textView.setText("HTML Tags are fundamental pieces of code which allows us as developers to organise and present relevant information.\n\n"
                +
                "Put simply, they are instructions which define how elements are structured on the web-page. It allows us to create a hierarchy of elements which influences the layout.\n\n"
                +
                "Tags need to be open and closed, this signifies the start and the end of the element. For example, to open a tag it will look like this - <tag>\n\n"
                +
                "Then to end the tag it will look slightly different to distinguish the two. A closing tag looks like this - </tag>");


        relativeLayout.addView(textView);


        ImageButton backArrowButton = findViewById(R.id.backArrow);

        backArrowButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                finish();
            }
        });
    }
}

