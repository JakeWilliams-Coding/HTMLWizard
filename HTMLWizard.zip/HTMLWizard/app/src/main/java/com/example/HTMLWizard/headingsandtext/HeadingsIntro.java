package com.example.HTMLWizard.headingsandtext;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.example.HTMLWizard.R;

public class HeadingsIntro extends AppCompatActivity {

    ImageButton html_intro_1;
    RelativeLayout relativeLayout;

    private ImageButton backArrowButton;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.base_activity_layout);

        html_intro_1 = findViewById(R.id.html_intro_1);

        html_intro_1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(com.example.HTMLWizard.headingsandtext.HeadingsIntro.this, TextElements.class);
                startActivity(intent);
            }
        });

        backArrowButton = findViewById(R.id.backArrow);
        backArrowButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        relativeLayout = findViewById(R.id.lesson_text);


        TextView textView = new TextView(this);
        textView.setLayoutParams(new RelativeLayout.LayoutParams(
                RelativeLayout.LayoutParams.WRAP_CONTENT,
                RelativeLayout.LayoutParams.WRAP_CONTENT));

        textView.setTextColor(ContextCompat.getColor(this, R.color.textColor));

        textView.setText("Headings help organize the content of a webpage, making it easier for users to navigate and understand the information presented. They provide a hierarchical structure that visually separates different sections of content.\n\n"
                +
                "Properly structured headings improve accessibility for users who rely on screen readers or other assistive technologies.\n\n"
                +
                "HTML provides six levels of headings, ranging from <h1> to <h6>. Each level represents a different level of importance and semantic meaning:\n\n"
                +
                "<h1>: This is the highest level heading and is typically used for the main title of the page. It should only be used once per page and represents the most important heading.\n\n"
                +
                "<h2>: These headings are used for section titles that are subordinate to the main title (<h1>). They represent the next level of importance.\n\n"
                +
                "<h3>, <h4>, <h5>, <h6>: These headings are used for subsections or subtopics within the content. As the number increases, the importance of the heading decreases. <h3> is more important than <h4>, and so on.");

        relativeLayout.addView(textView);
    }
}
