package com.example.HTMLWizard.htmlforms;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.example.HTMLWizard.R;

public class InputElements extends AppCompatActivity {

    ImageButton html_intro_1;
    RelativeLayout relativeLayout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.base_activity_layout);

        html_intro_1 = findViewById(R.id.html_intro_1);

        html_intro_1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(com.example.HTMLWizard.htmlforms.InputElements.this, CommonAttributes.class);
                startActivity(intent);
            }
        });

        relativeLayout = findViewById(R.id.lesson_text);


        TextView textView = new TextView(this);
        textView.setLayoutParams(new RelativeLayout.LayoutParams(
                RelativeLayout.LayoutParams.WRAP_CONTENT,
                RelativeLayout.LayoutParams.WRAP_CONTENT));

        textView.setText("< input > element: This element is used primarily for creating input fields for collecting user data. As you saw in the previous form example, the input element was shown. With this element you can have different types of inputs such as username, password, text etc. Here is an example of how it can be used: < input type=&quot; text &quot; name=username &quot; >, < input type= &quot; password &quot; name= &quot; password &quot; >\n\n"
                +
                "< textarea > element: This does a similar role to the < input > element, but this allows users to enter longer text into the field making it multi-line. This type of element can be used when a user needs to input an extended answer such as a feedback message or an address. With this element you can specify the size you would like it to be, so the user cannot overrun the input with too much text. Here is an example of it looks: < textarea name= &quot; message &quot;  rows= &quot; 4 &quot; cols= &quot; 50 &quot; > < /textarea >\n\n"
                +
                "< select > element: This element is used to create a dropdown menu for the user, through this you can provide a list of options which the user can choose from. This is important when you want to receive specific answers for the form. This also eliminates any spelling mistakes as well which can affect the results of the form. Here is an example of how this element can be used:\n\n"
                +
                "< select id= &quot; cars &quot; name= &quot; cars &quot; >\n" +
                "  < option value= &quot; volvo &quot; > Volvo < /option >\n" +
                "  < option value= &quot; saab &quot; > Saab < /option >\n" +
                "  < option value= &quot; fiat &quot; > Fiat < /option >\n" +
                "  < option value= &quot; audi &quot; > Audi < /option >\n" +
                "< /select >\n\n"
                +
                "> button < element: This element is used to create a clickable button for the user. We can programme this to do any specific function, but in the case of forms they are commonly used for submitting the form after it has been completed. Here is an example of how this element can be used: < button type= &quot; submit &quot; > Submit < /button >, < button onclick= &quot; myFunction() &quot; > Click me < /button >\n");

        relativeLayout.addView(textView);
    }
}