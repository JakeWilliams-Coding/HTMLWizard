package com.example.HTMLWizard.simplehtmltags;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.example.HTMLWizard.R;

public class AttributesInTags extends AppCompatActivity {

    ImageButton html_intro_1;
    RelativeLayout relativeLayout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.base_activity_layout);

        html_intro_1 = findViewById(R.id.html_intro_1);

        html_intro_1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(AttributesInTags.this, InteractiveQuizPt1.class);
                startActivity(intent);
            }
        });

        relativeLayout = findViewById(R.id.lesson_text);


        TextView textView = new TextView(this);
        textView.setLayoutParams(new RelativeLayout.LayoutParams(
                RelativeLayout.LayoutParams.WRAP_CONTENT,
                RelativeLayout.LayoutParams.WRAP_CONTENT));

        textView.setTextColor(ContextCompat.getColor(this, R.color.textColor));

        textView.setText("HTML tags are sometimes accompanied by attributes, they provide additional information that is used in the tags. Attributes are always defined in the opening tag and enclosed in quotation marks.\n\n"
                +
                "Attributes can enhance your web-page design in many different ways, for example they allow you to create visually appealing designs which will be consistent throughout the web-page. In on-coming lessons there will be more in-depth explanations on certain attributes and their functionality.\n\n"
                +
                "Here are some example attributes which show how they are structured when you are developing your web-page:\n\n"
                +
                "‘Id’ - The ‘id’ attribute provides a unique identifier for an element, it must always be a unique id whenever you use it. An example of this is as shown: ‘<div id=\"header\"> This is a header</div>\n\n'"
                +
                "‘Class’ - The ‘class’ attribute assigns one or more classes to an element. This is for the styling of your web-page; this attribute will be helpful when applying a change to multiple elements. An example of this can be: <p class=\"important\">This is an important paragraph</p>\n\n"
                +
                "‘Alt’ - The ‘alt’ attribute is used when an image on the web-page cannot be displayed or for accessibility purposes. It gives an image an alternate text which describes what the image is showing the user. An example of this can be: <img src=\"image.jpg\" alt=\"An example image\">");

        relativeLayout.addView(textView);

        ImageButton backArrowButton = findViewById(R.id.backArrow);
        backArrowButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                finish();
            }
        });

    }


}