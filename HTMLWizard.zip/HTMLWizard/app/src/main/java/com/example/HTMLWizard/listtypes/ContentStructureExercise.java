package com.example.HTMLWizard.listtypes;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.DragEvent;
import android.view.MotionEvent;
import android.view.View;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.example.HTMLWizard.R;
import com.example.HTMLWizard.simplehtmltags.TheBodyTag;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import androidx.appcompat.app.AppCompatActivity;

public class ContentStructureExercise extends AppCompatActivity {

    private TextView[] textViews;
    private RelativeLayout[] boxes;
    private FloatingActionButton nextButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tag_identification);

        textViews = new TextView[]{
                findViewById(R.id.textViewh1open),
                findViewById(R.id.textViewh1closed),
                findViewById(R.id.textViewh6open),
                findViewById(R.id.textViewh6closed),
                findViewById(R.id.textViewpopen),
                findViewById(R.id.textViewpclosed)
        };

        boxes = new RelativeLayout[]{
                findViewById(R.id.box1),
                findViewById(R.id.box2),
                findViewById(R.id.box3),
                findViewById(R.id.box4),
                findViewById(R.id.box5),
                findViewById(R.id.box6)
        };

        for (TextView textView : textViews) {
            textView.setOnTouchListener(touchListener);
        }

        for (RelativeLayout box : boxes) {
            box.setOnDragListener(dragListener);
        }


        //nextButton = findViewById(R.id.html_intro_1);
        nextButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                boolean isCorrect = areAllTextInCorrectBoxes();
                if (isCorrect) {
                    startActivity(new Intent(com.example.HTMLWizard.listtypes.ContentStructureExercise.this, TheBodyTag.class));
                } else {
                    Toast.makeText(com.example.HTMLWizard.listtypes.ContentStructureExercise.this, "Some answers are incorrect", Toast.LENGTH_SHORT).show();
                    for (int i = 0; i < textViews.length; i++) {
                        if (textViews[i].getParent() != boxes[i]) {
                            Log.d("TagIdentification", "TextView " + (i+1) + " is not in the correct box");
                        }
                    }
                }
            }
        });
    }

    private boolean areAllTextInCorrectBoxes() {
        for (int i = 0; i < textViews.length; i++) {
            TextView textView = textViews[i];
            RelativeLayout box = boxes[i];
            int textViewCenterX = (int) (textView.getX() + textView.getWidth() / 2);
            int textViewCenterY = (int) (textView.getY() + textView.getHeight() / 2);
            if (!(textViewCenterX >= box.getLeft() && textViewCenterX <= box.getRight() &&
                    textViewCenterY >= box.getTop() && textViewCenterY <= box.getBottom())) {
                return false;
            }
        }
        return true;

    }



    private final View.OnTouchListener touchListener = new View.OnTouchListener() {
        @Override
        public boolean onTouch(View v, MotionEvent event) {
            if (event.getAction() == MotionEvent.ACTION_DOWN) {
                View.DragShadowBuilder shadowBuilder = new View.DragShadowBuilder(v);
                v.startDragAndDrop(null, shadowBuilder, v, 0);
                return true;
            }
            return false;
        }
    };

    private final View.OnDragListener dragListener = new View.OnDragListener() {
        @Override
        public boolean onDrag(View v, DragEvent event) {
            int action = event.getAction();
            switch (action) {
                case DragEvent.ACTION_DROP:
                    View draggedView = (View) event.getLocalState();
                    RelativeLayout targetBox = (RelativeLayout) v;

                    int targetCenterX = targetBox.getLeft() + targetBox.getWidth() / 2;
                    int targetCenterY = targetBox.getTop() + targetBox.getHeight() / 2;

                    draggedView.setX(targetCenterX - draggedView.getWidth() / 2);
                    draggedView.setY(targetCenterY - draggedView.getHeight() / 2);
                    break;
            }
            return true;
        }
    };
}
