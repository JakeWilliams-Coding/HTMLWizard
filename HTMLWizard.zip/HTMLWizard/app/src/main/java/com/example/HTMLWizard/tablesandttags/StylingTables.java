package com.example.HTMLWizard.tablesandttags;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.example.HTMLWizard.R;
import com.example.HTMLWizard.headingsandtext.TextElements;

public class StylingTables extends AppCompatActivity {

    ImageButton html_intro_1;
    RelativeLayout relativeLayout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.base_activity_layout);

        html_intro_1 = findViewById(R.id.html_intro_1);

        html_intro_1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(com.example.HTMLWizard.tablesandttags.StylingTables.this, ResponsiveTables.class);
                startActivity(intent);
            }
        });

        relativeLayout = findViewById(R.id.lesson_text);

        TextView textView = new TextView(this);
        textView.setLayoutParams(new RelativeLayout.LayoutParams(
                RelativeLayout.LayoutParams.WRAP_CONTENT,
                RelativeLayout.LayoutParams.WRAP_CONTENT));

        textView.setText("In conjunction with CSS we are able to style the table however we desire, which improves the visual appearance on the web page. Below is some CSS code which you can use to style your own table on your web page. Play around with these values in your own time so you can visually see what each attribute does to the table first hand.\n\n"
                +
                "Changing Background Colors: th {\n" +
                "  background-color: #f2f2f2; /* light gray background for table headers */\n" +
                "}\n" +
                "\n" +
                "\n" +
                "td {\n" +
                "  background-color: #ffffff; /* white background for table data cells */\n" +
                "}\n\n"
                +
                "Customizing Borders:table {\n" +
                "  border-collapse: collapse; /* collapse borders to avoid double borders */\n" +
                "  border: 1px solid #cccccc; /* set a solid border around the entire table */\n" +
                "}\n" +
                "\n" +
                "\n" +
                "th, td {\n" +
                "  border: 1px solid #cccccc; /* set a solid border for table headers and data cells */\n" +
                "}\n\n"
                +
                "Adding Padding and Margin:th, td {\n" +
                "  padding: 10px; /* add 10 pixels of padding to table headers and data cells */\n" +
                "  margin: 5px; /* add 5 pixels of margin around table headers and data cells */\n" +
                "}\n");

        relativeLayout.addView(textView);
    }
}