package com.example.HTMLWizard.htmlforms;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.example.HTMLWizard.R;

public class HTMLFormsIntro extends AppCompatActivity {

    ImageButton html_intro_1;
    RelativeLayout relativeLayout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.base_activity_layout);

        html_intro_1 = findViewById(R.id.html_intro_1);

        html_intro_1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(com.example.HTMLWizard.htmlforms.HTMLFormsIntro.this, FormStructure.class);
                startActivity(intent);
            }
        });

        relativeLayout = findViewById(R.id.lesson_text);


        TextView textView = new TextView(this);
        textView.setLayoutParams(new RelativeLayout.LayoutParams(
                RelativeLayout.LayoutParams.WRAP_CONTENT,
                RelativeLayout.LayoutParams.WRAP_CONTENT));

        textView.setText("HTML forms are an important component for a web page, it is helpful in collecting numerous types of input data from the user. Examples of this can be buttons, drawdown menus, checkboxes etc. They assist with goals we are trying to achieve while creating a web page, below are some examples of this.\n\n"
                +
                "User Retention: This area is important as it brings users back to your website and depending on what the website is used for, can be a breaking point. Forms allow users to interact with a website choosing information or providing written feedback.\n\n"
                +
                "User Authentication: We use forms commonly for user authentication for example, create an account page or a login page. This is where the user will input their credentials and then redirect to the next page.\n\n"
                +
                "Data Collections: This allows the user to insert any data they want and then store it to a server. Examples of this can be surveys or any social media posts where the user can interact with it");

        relativeLayout.addView(textView);
    }
}