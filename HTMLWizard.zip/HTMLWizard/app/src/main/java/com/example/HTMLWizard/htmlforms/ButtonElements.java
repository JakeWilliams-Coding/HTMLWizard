package com.example.HTMLWizard.htmlforms;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.example.HTMLWizard.R;

public class ButtonElements extends AppCompatActivity {

    ImageButton html_intro_1;
    RelativeLayout relativeLayout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.base_activity_layout);

        html_intro_1 = findViewById(R.id.html_intro_1);

        html_intro_1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(com.example.HTMLWizard.htmlforms.ButtonElements.this, ClosingFormTags.class);
                startActivity(intent);
            }
        });

        relativeLayout = findViewById(R.id.lesson_text);


        TextView textView = new TextView(this);
        textView.setLayoutParams(new RelativeLayout.LayoutParams(
                RelativeLayout.LayoutParams.WRAP_CONTENT,
                RelativeLayout.LayoutParams.WRAP_CONTENT));

        textView.setText("The < button > tag is used to create a button for the user to click, we can use buttons to have specific functions. One being used within HTML forms for submitting the form, taking the user to a different page or activating a javascript function on the page. It provides the user with a visual identifier for completing an action and requires only a single click of the button to complete the intended function.\n\n"
                +
                "Role in forms: Form submission: As stated above, we can use buttons to submit a form to a server if we programme it to do so. We can add in the < form > element into the button code and then change the type to &quot; submit &quot; and then can use the button as a functional submit button for the form.\n\n"
                +
                "We can also trigger specific javascript functions which are sets of statements which perform a task very quickly. We won’t dive into this too much as we are just learning the basics of HTML programming. We can essentially call a function and then it will be executed live via javascript.\n\n"
                +
                "Below is an example of how we can structure a HTML form with the different attributes as mentioned previously:\n\n"
                +
                "< form action= &quot; /submit_form.php &quot; method=&quot; post &quot; >\n" +
                "    < !-- Form content goes here -- >\n" +
                "    < input type= &quot; text &quot; name= &quot; username &quot;  placeholder= &quot; Username &quot; >\n" +
                "    < input type= &quot; password &quot; name= &quot; password &quot;  placeholder= &quot; Password &quot; >\n" +
                "    < button type= &quot; submit &quot; > Submit </ button >\n" +
                "< /form >");

        relativeLayout.addView(textView);
    }
}
