package com.example.HTMLWizard.ImagesAndAudio;

public class QuestionAnswerIA {

    public static String question[] ={
            "What does the loop attribute do?", //0
            "Which audio format provides the highest audio quality?",//1
            "Which attribute is used to provide alternative text for an image?", //2
    };

    public static String choices[][] = {
            {"It preloads the audio in your web-page","Restarts audio when it has finished","It allows you to adjust the volume of the audio","Allows you to adjust the audio speed"},
            {"AAC","MP4","MP3","WAV"},
            {"Alt","Img","Src","Height"},
    };

    public static String correctAnswers[] = {
            "Restarts audio when it has finished",
            "WAV",
            "Alt",
    };

}
