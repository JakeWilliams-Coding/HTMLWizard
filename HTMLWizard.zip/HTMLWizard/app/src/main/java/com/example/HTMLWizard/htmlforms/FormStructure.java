package com.example.HTMLWizard.htmlforms;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.example.HTMLWizard.R;

public class FormStructure extends AppCompatActivity {

    ImageButton html_intro_1;
    RelativeLayout relativeLayout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.base_activity_layout);

        html_intro_1 = findViewById(R.id.html_intro_1);

        html_intro_1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(com.example.HTMLWizard.htmlforms.FormStructure.this, InputElements.class);
                startActivity(intent);
            }
        });

        relativeLayout = findViewById(R.id.lesson_text);


        TextView textView = new TextView(this);
        textView.setLayoutParams(new RelativeLayout.LayoutParams(
                RelativeLayout.LayoutParams.WRAP_CONTENT,
                RelativeLayout.LayoutParams.WRAP_CONTENT));

        textView.setText("When using forms we need to maintain some structure for them to work how we want them to. Using different attributes and tags will change the way it is displayed on your web page. It’s important to play around with these to fully understand how it functions. The <form> tag defines your forms. Any forms you want embedded in your page and should be placed inside these tags.\n\n"
                +
                "Action Attribute: This attribute specifies the URL which the data will be sent to be processed. In the example the \"/submit_form.php\" is where the data will be sent to.\n\n"
                +
                "Method Attribute: This is what defines the HTTP method that is used to send the form data to a server. As seen in the example there is “post” which sends the form data to a server to create or update a resource. There is also “get” which is primarily used for retrieving data and becomes visible in the address bar.\n\n"
                +
                "When we have forms we need something called form validation, this ensures the data entered by the user meets the set out criteria before it is submitted to the server. Examples of this can be correct email address insertion or making sure all the required fields in the form have been completed.\n\n"
                +
                "< form action=’/submit_form.php’ method=’post’ >\n" +
                "    < !-- Form content goes here -- >\n" +
                "    < input type=’text’ name=’username’ placeholder=’Username’ >\n" +
                "    < input type=’password’ name=’password’ placeholder=’Password’ >\n" +
                "    < button type=’submit’ > Submit </button >\n" +
                "</ form >\n");

        relativeLayout.addView(textView);
    }
}