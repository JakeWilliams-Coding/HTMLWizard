package com.example.HTMLWizard.tablesandttags;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.example.HTMLWizard.R;

public class ResponsiveTables extends AppCompatActivity {

    ImageButton html_intro_1;
    RelativeLayout relativeLayout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.base_activity_layout);

        html_intro_1 = findViewById(R.id.html_intro_1);

        html_intro_1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(com.example.HTMLWizard.tablesandttags.ResponsiveTables.this, ConclusionTT.class);
                startActivity(intent);
            }
        });

        relativeLayout = findViewById(R.id.lesson_text);

        TextView textView = new TextView(this);
        textView.setLayoutParams(new RelativeLayout.LayoutParams(
                RelativeLayout.LayoutParams.WRAP_CONTENT,
                RelativeLayout.LayoutParams.WRAP_CONTENT));

        textView.setText("A responsive table in HTML is when it includes a horizontal scrollbar if the screen size is too small to fit the entirety of the table on it. It adapts well to various screen sizes, especially on any mobile devices where the screen size is almost always a small one. Responsive tables are essential for website design as it means any user, on any device is able to view the information in your table.\n\n"
                +
                "As stated above it uses horizontal scrolling for tables with more columns than the screen width can fit. This will prevent overflowing and any disorganised elements on the screen for those smaller devices. We can use CSS code such as: overflow-x: auto; to enable horizontal scrolling into our table.\n\n"
                +
                "Additionally to help with user experience we can set the width of the table to a percentage and not a fixed width for every screen size, this can cause complications as it may look perfect on one screen size but untidy on another screen size. We can use a percentage such as 100%, this will set the width of the table to 100% of the parent container which it is embedded in.\n\n"
                +
                "We can also use a technique where we stock rows vertically inside or horizontally. This is aimed towards smaller mobile devices which makes it easier for the user to scroll vertically on their smaller screen size.");

        relativeLayout.addView(textView);
    }
}