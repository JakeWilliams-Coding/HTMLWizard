package com.example.HTMLWizard.bigquiz;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.DragEvent;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;


import com.example.HTMLWizard.R;

public class listTypesQ extends AppCompatActivity {

    private TextView[] textViews;
    private RelativeLayout[] boxes;
    private Button mainSubmitButton;
    private ImageButton backArrowButton;
    private Button clearButton;

    private float[] originalXPositions;
    private float[] originalYPositions;
    private boolean isOriginalPositionsSet = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list_types_q);


        textViews = new TextView[]{
                findViewById(R.id.textViewdl),
                findViewById(R.id.textViewol),
                findViewById(R.id.textViewul)

        };


        boxes = new RelativeLayout[]{
                findViewById(R.id.box1),
                findViewById(R.id.box2),
                findViewById(R.id.box3)

        };


        for (TextView textView : textViews) {
            textView.setOnTouchListener(touchListener);
        }


        for (RelativeLayout box : boxes) {
            box.setOnDragListener(dragListener);
        }

        // Initialize nextButton
        mainSubmitButton = findViewById(R.id.submitButton);
        mainSubmitButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                boolean isCorrect = areAllTextInCorrectBoxes();
                if (isCorrect) {
                    startActivity(new Intent(listTypesQ.this, CSSstylingQ.class));
                } else {
                    Toast.makeText(listTypesQ.this, "Some answers are incorrect", Toast.LENGTH_SHORT).show();




                    for (int i = 0; i < textViews.length; i++) {
                        if (textViews[i].getParent() != boxes[i]) {
                            Log.d("", "TextView " + (i + 1) + " is not in the correct box");
                        }
                    }
                }
            }
        });


        backArrowButton = findViewById(R.id.backArrow);
        backArrowButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                finish();
            }
        });


        clearButton = findViewById(R.id.clearbutton);
        clearButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                resetTextViewsPositions();
            }
        });
    }

    private void setOriginalPositions() {
        if (!isOriginalPositionsSet) {
            originalXPositions = new float[textViews.length];
            originalYPositions = new float[textViews.length];
            for (int i = 0; i < textViews.length; i++) {
                originalXPositions[i] = textViews[i].getX();
                originalYPositions[i] = textViews[i].getY();
            }
            isOriginalPositionsSet = true;
        }
    }

    private void resetTextViewsPositions() {
        setOriginalPositions();
        for (int i = 0; i < textViews.length; i++) {
            textViews[i].setX(originalXPositions[i]);
            textViews[i].setY(originalYPositions[i]);
        }
    }

    private boolean areAllTextInCorrectBoxes() {
        for (int i = 0; i < textViews.length; i++) {
            TextView textView = textViews[i];
            RelativeLayout box = boxes[i];

            int textViewCenterX = (int) (textView.getX() + textView.getWidth() / 2);
            int textViewCenterY = (int) (textView.getY() + textView.getHeight() / 2);
            if (!(textViewCenterX >= box.getLeft() && textViewCenterX <= box.getRight() &&
                    textViewCenterY >= box.getTop() && textViewCenterY <= box.getBottom())) {
                return false;
            }
        }
        return true;
    }

    private final View.OnTouchListener touchListener = new View.OnTouchListener() {
        @Override
        public boolean onTouch(View v, MotionEvent event) {
            if (event.getAction() == MotionEvent.ACTION_DOWN) {
                View.DragShadowBuilder shadowBuilder = new View.DragShadowBuilder(v);
                v.startDragAndDrop(null, shadowBuilder, v, 0);
                setOriginalPositions();
                return true;
            }
            return false;
        }
    };


    private final View.OnDragListener dragListener = new View.OnDragListener() {
        @Override
        public boolean onDrag(View v, DragEvent event) {
            int action = event.getAction();
            switch (action) {
                case DragEvent.ACTION_DROP:
                    View draggedView = (View) event.getLocalState();
                    RelativeLayout targetBox = (RelativeLayout) v;

                    int targetCenterX = targetBox.getLeft() + targetBox.getWidth() / 2;
                    int targetCenterY = targetBox.getTop() + targetBox.getHeight() / 2;

                    draggedView.setX(targetCenterX - draggedView.getWidth() / 2);
                    draggedView.setY(targetCenterY - draggedView.getHeight() / 2);
                    break;
            }
            return true;
        }
    };
}