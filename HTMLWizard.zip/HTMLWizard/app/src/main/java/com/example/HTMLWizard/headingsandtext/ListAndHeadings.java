package com.example.HTMLWizard.headingsandtext;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.example.HTMLWizard.R;

public class ListAndHeadings extends AppCompatActivity {

    ImageButton html_intro_1;
    RelativeLayout relativeLayout;

    private ImageButton backArrowButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.base_activity_layout);

        html_intro_1 = findViewById(R.id.html_intro_1);

        html_intro_1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(com.example.HTMLWizard.headingsandtext.ListAndHeadings.this, InteractiveQuizHT.class);
                startActivity(intent);
            }
        });


        backArrowButton = findViewById(R.id.backArrow);
        backArrowButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });


        relativeLayout = findViewById(R.id.lesson_text);


        TextView textView = new TextView(this);
        textView.setLayoutParams(new RelativeLayout.LayoutParams(
                RelativeLayout.LayoutParams.WRAP_CONTENT,
                RelativeLayout.LayoutParams.WRAP_CONTENT));


        textView.setTextColor(ContextCompat.getColor(this, R.color.textColor));

        textView.setText("While headings define the hierarchy and sections of content, lists are used to present information in a structured and ordered manner. The relationship between headings and lists lies in how headings can be used to structure content within lists, providing additional context and organization.\n\n"
                +
                "Heading within a List Item: You can include headings (such as <h2>, <h3>, etc.) within list items (<li>) to further organize and clarify the content within each list item. This is particularly useful when a list item contains multiple sections or subsections of content. <ul>\n\n" +
                "  <li>\n" +
                "    <h2>Main Heading</h2>\n" +
                "    <p>Some description...</p>\n" +
                "  </li>\n" +
                "  <li>\n" +
                "    <h2>Another Heading</h2>\n" +
                "    <p>Some description...</p>\n" +
                "  </li>\n" +
                "</ul>\n\n"
                +

                "List within a Heading: Similarly, you can include lists (ordered or unordered) within headings to present structured content under a specific section. This is helpful when you want to group related items or subtopics under a main heading. <h2>Main Heading</h2>\n\n" +
                "<ul>\n" +
                "  <li>Item 1</li>\n" +
                "  <li>Item 2</li>\n" +
                "</ul>\n"
                +

                "Hierarchical Structure: By combining headings and lists, you can create a hierarchical structure that clearly defines the relationships between different sections and sub-sections of content on your webpage. For instance, you might use <h2> headings for main sections and <h3> headings for sub-sections within each main section, with lists providing additional details or items within each subsection. <h2>Main Section</h2>\n\n" +
                "<ul>\n" +
                "  <li>\n" +
                "    <h3>Subsection 1</h3>\n" +
                "    <p>Some description...</p>\n" +
                "  </li>\n" +
                "  <li>\n" +
                "    <h3>Subsection 2</h3>\n" +
                "    <p>Some description...</p>\n" +
                "  </li>\n" +
                "</ul>");

        relativeLayout.addView(textView);
    }
}
