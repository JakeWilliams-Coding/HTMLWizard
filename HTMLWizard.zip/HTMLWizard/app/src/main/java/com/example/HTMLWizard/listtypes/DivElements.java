package com.example.HTMLWizard.listtypes;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.example.HTMLWizard.R;

public class DivElements extends AppCompatActivity {

    ImageButton html_intro_1;
    RelativeLayout relativeLayout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.base_activity_layout);

        html_intro_1 = findViewById(R.id.html_intro_1);

        html_intro_1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(com.example.HTMLWizard.listtypes.DivElements.this, ConclusionLT.class);
                startActivity(intent);
            }
        });


        relativeLayout = findViewById(R.id.lesson_text);


        TextView textView = new TextView(this);
        textView.setLayoutParams(new RelativeLayout.LayoutParams(
                RelativeLayout.LayoutParams.WRAP_CONTENT,
                RelativeLayout.LayoutParams.WRAP_CONTENT));

        textView.setText("Here is where we introduce the < div > element into our lists, it can be a flexible container for list content on the web page. We can use it purely for organising content on the web page and it creates a professional looking effect when integrated. We can use this element for group content, this makes it easier to apply specific styles for a target list.\n\n"
                +
                "Layout Structure: We can use the < div > element to create the layout structure of a webpage by defining specific sections through it. The use of headers, footers and sidebars are a key concept with styling with the < div > tag. With this we can style how they appear through CSS, we are able to control many aspects such as positioning, colour and other visual assets. We can give the tag an ID for a specific styling purpose, below is an example of how a < div > tag can be given an ID and enhanced with CSS.\n\n"
                +
                "html:\n" +
                "\n" +
                "< div class=\"sidebar\" >\n" +
                "    < ul >\n" +
                "        < li >Item 1< /li >\n" +
                "        < li >Item 2< /li >\n" +
                "        < li >Item 3< /li >\n" +
                "    < /ul >\n" +
                "< /div >\n\n"
                +
                "css:\n" +
                "\n" +
                ".sidebar ul {\n" +
                "    list-style-type: none;\n" +
                "    margin: 0;\n" +
                "    padding: 0;\n" +
                "}\n" +
                ".sidebar li {\n" +
                "    padding: 5px;\n" +
                "}\n");

        relativeLayout.addView(textView);
    }
}