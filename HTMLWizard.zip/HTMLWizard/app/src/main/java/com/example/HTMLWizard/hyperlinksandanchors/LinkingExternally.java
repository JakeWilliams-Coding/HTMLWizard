package com.example.HTMLWizard.hyperlinksandanchors;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.example.HTMLWizard.R;

public class LinkingExternally extends AppCompatActivity {

    ImageButton html_intro_1;
    RelativeLayout relativeLayout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.base_activity_layout);

        html_intro_1 = findViewById(R.id.html_intro_1);

        html_intro_1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(com.example.HTMLWizard.hyperlinksandanchors.LinkingExternally.this, ConclusionHA.class);
                startActivity(intent);
            }
        });

        relativeLayout = findViewById(R.id.lesson_text);


        TextView textView = new TextView(this);
        textView.setLayoutParams(new RelativeLayout.LayoutParams(
                RelativeLayout.LayoutParams.WRAP_CONTENT,
                RelativeLayout.LayoutParams.WRAP_CONTENT));

        textView.setText("When we are linking external resources into our website, the way we must do this changes on what we are trying to link. We must directly specify what we are linking to the browser and know what it should be fetching for the user. Other than linking other websites we can also do documents and images.\n\n"
                +
                "To link a document such as a PDF we need to specify in its URL that it is in a PDF file format. For this type we can use the < a > tag again while inserting the URL where the document is based. Here is an example of how we can link a PDF file: < a href= &quot; https://random.com/example.pdf &quot; >Download Document< /a >\n\n"
                +
                "Then we have images which we can directly link from our web page. This is using the src attribute which will specify to the browser where to fetch the images. Here is an example of how you can link an image: < img src= &quot; https://random.com/image.jpg &quot; alt= &quot; Image Description &quot; >\n");

        relativeLayout.addView(textView);
    }
}