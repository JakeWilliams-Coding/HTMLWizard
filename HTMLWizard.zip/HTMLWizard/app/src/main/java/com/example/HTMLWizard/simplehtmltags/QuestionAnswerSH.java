package com.example.HTMLWizard.simplehtmltags;


public class QuestionAnswerSH {


    public static String question[] ={
            "Which one of these answers is an opening body tag?", //0
            "What does the body tag do?", //1
            "What is the purpose of attributes?", //2
            "In the box below create a comment saying ‘This is a comment’" //3
    };

    public static String choices[][] = {
            {"<body>","<!body!>","</body>","<<body>>"},
            {"Set the page title","Defines the colours in the web-page","Contains the content of the web-page","Defines the font"},
            {"Provides additional information about HTML elements","Defines the structure of the web-page","Changes the colour of the text","Plays music and videos on the web-apge"},
            {"<!--This is a comment-->"},
    };

    public static String correctAnswers[] = {
            "<body>",
            "Contains the content of the web-page",
            "Provides additional information about HTML elements",
            "<!--This is a comment-->",
    };

}
