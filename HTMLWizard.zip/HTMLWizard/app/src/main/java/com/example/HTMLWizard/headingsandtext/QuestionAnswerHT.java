package com.example.HTMLWizard.headingsandtext;

public class QuestionAnswerHT {

    public static String question[] ={
            "Which HTML tag is used for the main heading of a webpage?", //0

    };

    public static String choices[][] = {
            {"<h2>","<h6>","<h3>","<h1>"},

    };

    public static String correctAnswers[] = {
            "<h1>",

    };

}
