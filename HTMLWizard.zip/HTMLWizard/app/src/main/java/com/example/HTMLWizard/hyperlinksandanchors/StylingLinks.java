package com.example.HTMLWizard.hyperlinksandanchors;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.example.HTMLWizard.R;

public class StylingLinks extends AppCompatActivity {

    ImageButton html_intro_1;
    RelativeLayout relativeLayout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.base_activity_layout);

        html_intro_1 = findViewById(R.id.html_intro_1);

        html_intro_1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(com.example.HTMLWizard.hyperlinksandanchors.StylingLinks.this, LinkingExternally.class);
                startActivity(intent);
            }
        });


        relativeLayout = findViewById(R.id.lesson_text);


        TextView textView = new TextView(this);
        textView.setLayoutParams(new RelativeLayout.LayoutParams(
                RelativeLayout.LayoutParams.WRAP_CONTENT,
                RelativeLayout.LayoutParams.WRAP_CONTENT));

        textView.setText("In HTML we can style hyperlinks any way we like, you can make them stand out and visually enhance your web page. It also provides some alternative use as it can improve readability for those who may be colour blind or have any other visual impairments. Here are some CSS additions you can make in order to style your hyperlinks.\n\n"
                 +
                "color: Sets the color of the text.\n" +
                "text-decoration: Controls the appearance of the underline (or none) for the link text.\n" +
                "font-weight: Specifies the thickness of the text.\n" +
                "font-style: Sets the style of the text (such as italic).\n" +
                "background-color: Defines the background color behind the link text.\n" +
                "\n" +
                "\n" +
                "\n" +
                "a {\n" +
                "    color: #007bff; /* Blue color */\n" +
                "    text-decoration: none; /* Remove underline */\n" +
                "    font-weight: bold; /* Bold text */\n" +
                "}\n" +
                "\n" +
                "a:hover {\n" +
                "    text-decoration: underline; /* Underline on hover */\n" +
                "    color: #0056b3; /* Darker blue color */\n" +
                "    background-color: #f0f0f0; /* Light gray background on hover */\n" +
                "}\n\n");

        relativeLayout.addView(textView);
    }
}