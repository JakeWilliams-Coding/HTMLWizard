package com.example.HTMLWizard.ImagesAndAudio;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.example.HTMLWizard.R;

public class MultimediaIntro extends AppCompatActivity {

    ImageButton html_intro_1;
    RelativeLayout relativeLayout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.base_activity_layout);

        html_intro_1 = findViewById(R.id.html_intro_1);

        html_intro_1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(com.example.HTMLWizard.ImagesAndAudio.MultimediaIntro.this, AddingImages.class);
                startActivity(intent);
            }
        });

        relativeLayout = findViewById(R.id.lesson_text);


        TextView textView = new TextView(this);
        textView.setLayoutParams(new RelativeLayout.LayoutParams(
                RelativeLayout.LayoutParams.WRAP_CONTENT,
                RelativeLayout.LayoutParams.WRAP_CONTENT));

        textView.setTextColor(ContextCompat.getColor(this, R.color.textColor));

        textView.setText("Enhanced User Experience: Multimedia elements such as images and audio can make any web page more engaging for a user. They can provide the user with an increased amount of information on the topic and make a web page look professional for an enhanced user experience.\n\n"
                +
                "Visual Communication: Images are at the forefront for visual communication along with videos. They can provide a user with sufficient information on a topic in an engaging, artistic style. High quality images can make a web page more visually appealing and improve user retention.\n\n"
                +
                "Accessibility: Multimedia also plays a part in overall accessibility of the web page. Alt text for images can provide users with visual impairment with assistance when understanding the content of the image. Vice versa, audio transcripts can be provided to those who have hearing impairments.\n");

        relativeLayout.addView(textView);
    }
}