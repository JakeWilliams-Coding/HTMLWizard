package com.example.HTMLWizard.listtypes;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.example.HTMLWizard.R;

public class NestedLists extends AppCompatActivity {

    ImageButton html_intro_1;
    RelativeLayout relativeLayout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.base_activity_layout);

        html_intro_1 = findViewById(R.id.html_intro_1);

        html_intro_1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(com.example.HTMLWizard.listtypes.NestedLists.this, DivElements.class);
                startActivity(intent);
            }
        });

        relativeLayout = findViewById(R.id.lesson_text);


        TextView textView = new TextView(this);
        textView.setLayoutParams(new RelativeLayout.LayoutParams(
                RelativeLayout.LayoutParams.WRAP_CONTENT,
                RelativeLayout.LayoutParams.WRAP_CONTENT));

        textView.setText("We also have Nested lists which is where we place a list within another list. This allows us to make smaller sub categories in our lists where it may be needed. It isn’t a new tag, it is the combination of the 2 previous list types. Below is an example of how you can structure a nested list:\n\n"
                +
                "< ul >\n" +
                "    < li >Search Engines\n" +
                "        < ul >\n" +
                "            < li > Google < >/li >\n" +
                "            < li > Yahoo < /li >\n" +
                "            < li  > Bing < /li >\n" +
                "        < /ul >\n" +
                "    < /li >\n" +
                "    < li >Furniture\n" +
                "        < ul >\n" +
                "            < li > Chair< /li >\n" +
                "            < li >Sofa</li>\n" +
                "            < li >Bed < /li >\n" +
                "        < /ul >\n" +
                "    < /li >\n" +
                "< /ul >\n\n"
                +
                "In this example ‘Search Engines’ and ‘Furniture’ are the list items for the outer unordered list. Within this it contains nested unordered lists which are the three pieces of text below it. This structure allows us to make sub categories within a list.\n");

        relativeLayout.addView(textView);
    }
}