package com.example.HTMLWizard;

import static org.junit.Assert.*;

import org.junit.Test;

public class CreateAccountActivityTest {

    @Test
    public void onCreate() {
    }

    @Test
    public void createAccount() {
    }

    @Test
    public void createAccountInFirebase() {
    }

    @Test
    public void changeInProgress() {
    }

    @Test
    public void validateData() {
    }
}