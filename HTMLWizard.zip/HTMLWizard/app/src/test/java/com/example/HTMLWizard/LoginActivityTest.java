package com.example.HTMLWizard;

import static org.junit.Assert.*;

import org.junit.Test;

public class LoginActivityTest {

    @Test
    public void onCreate() {
    }

    @Test
    public void loginUser() {
    }

    @Test
    public void loginAccountInFirebase() {
    }

    @Test
    public void changeInProgress() {
    }

    @Test
    public void validateData() {
    }

    @Test
    public void pushNodesToDatabase() {
    }
}