package com.example.HTMLWizard;

import static org.junit.Assert.*;

import org.junit.Test;

public class ChatbotFragmentTest {

    @Test
    public void onCreateView() {
    }

    @Test
    public void addToChat() {
    }

    @Test
    public void addResponse() {
    }

    @Test
    public void callAPI() {
    }
}