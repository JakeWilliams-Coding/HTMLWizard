package com.example.HTMLWizard;

import static org.junit.Assert.*;

import org.junit.Test;

public class MyprofileFragmentTest {

    @Test
    public void onCreateView() {
    }

    @Test
    public void onPause() {
    }

    @Test
    public void onResume() {
    }

    @Test
    public void onRequestPermissionsResult() {
    }
}