package com.example.HTMLWizard;

import static org.junit.Assert.*;

import org.junit.Test;

public class LearnFragmentTest {

    @Test
    public void onCreateView() {
    }
}