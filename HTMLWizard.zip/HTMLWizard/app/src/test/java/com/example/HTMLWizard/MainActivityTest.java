package com.example.HTMLWizard;

import static org.junit.Assert.*;

import org.junit.Test;

public class MainActivityTest {

    @Test
    public void onCreate() {
    }
}