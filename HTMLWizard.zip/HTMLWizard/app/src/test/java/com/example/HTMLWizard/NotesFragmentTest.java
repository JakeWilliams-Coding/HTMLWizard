package com.example.HTMLWizard;

import static org.junit.Assert.*;

import org.junit.Test;

public class NotesFragmentTest {

    @Test
    public void onCreateView() {
    }

    @Test
    public void onViewCreated() {
    }

    @Test
    public void showMenu() {
    }

    @Test
    public void setupRecyclerView() {
    }

    @Test
    public void onStart() {
    }

    @Test
    public void onStop() {
    }

    @Test
    public void onResume() {
    }
}